"""
Student Reference Solution Guide for GenomeDSL (25% Reserved Work).
This file contains the completed reference implementations for all 4 student tasks.
Students can study these functions to understand the biological logic, AST transformations,
and algorithms before completing them in their respective modules.

Tasks:
1. Task 1: Protein Alphabet Validation (semantic_analyzer.py)
2. Task 2: Sequence Comparison Semantics & Similarity Metric (backend.py)
3. Task 3: 1-Based Motif Search with Overlaps (backend.py)
4. Task 4: Reversible Operation AST Cancellation (optimizer.py)
"""

from typing import List, Optional, Set
from genomedsl.ast_nodes import Expr, FunctionCall
from genomedsl.errors import AlphabetError, BiologicalTypeError

# Standard 20 amino acid codes + '*' for translation stop codon
STANDARD_PROTEIN_ALPHABET: Set[str] = {
    "A", "C", "D", "E", "F", "G", "H", "I", "K", "L",
    "M", "N", "P", "Q", "R", "S", "T", "V", "W", "Y", "*"
}


# =============================================================================
# Task 1: Protein Alphabet Validation (Target: genomedsl/semantic_analyzer.py)
# =============================================================================
def reference_validate_protein_alphabet(seq: str, line: Optional[int] = None, column: Optional[int] = None) -> None:
    """
    Validates that every character in the sequence belongs to the standard 20 amino acids.
    Raises AlphabetError if any non-standard residue is found.
    """
    for char in seq.strip().upper():
        if char not in STANDARD_PROTEIN_ALPHABET:
            raise AlphabetError(
                f"Invalid amino acid '{char}'. Protein sequences only accept standard amino acid single-letter codes",
                line=line,
                column=column,
            )


# =============================================================================
# Task 2: Sequence Similarity Metric (Target: genomedsl/backend.py)
# =============================================================================
def reference_compare_sequences(seq1: str, seq2: str) -> float:
    """
    Calculates percentage identity between two biological sequences.
    Formula:
        matches = sum(1 for a, b in zip(seq1, seq2) if a == b)
        identity = (matches / max(len(seq1), len(seq2))) * 100.0
    """
    if not seq1 and not seq2:
        return 100.0
    max_len = max(len(seq1), len(seq2))
    if max_len == 0:
        return 0.0
    min_len = min(len(seq1), len(seq2))
    matches = sum(1 for a, b in zip(seq1[:min_len], seq2[:min_len]) if a == b)
    return round((matches / max_len) * 100.0, 2)


# =============================================================================
# Task 3: 1-Based Motif Search with Overlaps (Target: genomedsl/backend.py)
# =============================================================================
def reference_find_motif(sequence: str, motif: str) -> List[int]:
    """
    Finds all 1-based start coordinates of 'motif' in 'sequence'.
    Supports overlapping matches (e.g. searching 'AAA' in 'AAAA').
    """
    if not motif or not sequence:
        return []
    positions = []
    pos = sequence.find(motif, 0)
    while pos != -1:
        # Convert 0-based Python string index to 1-based biological coordinate
        positions.append(pos + 1)
        # Advance by 1 to detect overlapping occurrences
        pos = sequence.find(motif, pos + 1)
    return positions


# =============================================================================
# Task 4: Reversible Operation Cancellation (Target: genomedsl/optimizer.py)
# =============================================================================
def reference_simplify_reversible_calls(call: FunctionCall, stats_dict: dict) -> Expr:
    """
    Detects nested reversible operations:
    - reverse(reverse(x)) -> x
    - reverse_complement(reverse_complement(x)) -> x
    """
    if call.name in ("reverse", "reverse_complement") and len(call.args) == 1:
        inner = call.args[0]
        if isinstance(inner, FunctionCall) and inner.name == call.name and len(inner.args) == 1:
            # Reversible pair cancelled!
            stats_dict["reversible_reductions"] += 1
            return inner.args[0]
    return call
