"""
End-to-End (E2E) Integration tests for GenomeDSL.
Executes scripts directly through the compiler pipeline.
"""

import os
from genomedsl.cli import run_pipeline


def test_e2e_basic_pipeline(tmp_path):
    with open("examples/01_basic_pipeline.gdsl", "r") as f:
        code = f.read()

    success, backend = run_pipeline(code, file_name="01_basic_pipeline.gdsl", output_dir=str(tmp_path))
    assert success is True
    assert backend is not None
    assert backend.env["gene"][0] == "ATGCGTACCGTA"
    assert backend.env["rna1"][0] == "AUGCGUACCGUA"
    assert backend.env["protein1"][0] == "MRTV"
    assert backend.env["gc"][0] == 50.0


def test_e2e_gc_analysis_and_plot(tmp_path):
    with open("examples/02_gc_analysis.gdsl", "r") as f:
        code = f.read()

    success, backend = run_pipeline(code, file_name="02_gc_analysis.gdsl", output_dir=str(tmp_path))
    assert success is True
    assert backend is not None
    assert len(backend.generated_plots) == 1
    assert os.path.exists(backend.generated_plots[0])


def test_e2e_error_invalid_dna():
    with open("examples/04_error_invalid_dna.gdsl", "r") as f:
        code = f.read()

    success, backend = run_pipeline(code, file_name="04_error_invalid_dna.gdsl")
    assert success is False
    assert backend is None


def test_e2e_error_type_mismatch():
    with open("examples/05_error_type_mismatch.gdsl", "r") as f:
        code = f.read()

    success, backend = run_pipeline(code, file_name="05_error_type_mismatch.gdsl")
    assert success is False
    assert backend is None


def test_e2e_error_undeclared():
    with open("examples/06_error_undeclared.gdsl", "r") as f:
        code = f.read()

    success, backend = run_pipeline(code, file_name="06_error_undeclared.gdsl")
    assert success is False
    assert backend is None
