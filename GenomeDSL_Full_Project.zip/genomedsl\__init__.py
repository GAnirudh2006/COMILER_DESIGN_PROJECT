"""
GenomeDSL: A Domain-Specific Programming Language for DNA, RNA and Protein Sequence Analysis.
"""

__version__ = "0.1.0"
