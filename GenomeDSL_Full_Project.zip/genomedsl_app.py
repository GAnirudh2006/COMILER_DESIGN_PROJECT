"""
GenomeDSL — Professional Biological Programming Studio & Learning Academy
Editorial Soft English Aesthetic • Full Compiler Architecture • Restored Visual Graphs
"""

import os
import sys
import shutil
import tempfile
from typing import Dict, List, Any, Optional

import streamlit as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Ensure local package import
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from genomedsl.parser import parse_code
from genomedsl.semantic_analyzer import analyze_code
from genomedsl.optimizer import ASTOptimizer
from genomedsl.backend import ExecutionBackend
from genomedsl.visualizer import plot_gc_content_window, compute_sliding_window_gc
from genomedsl.grammar import GENOMEDSL_GRAMMAR
from genomedsl.errors import (
    GenomeDSLError, BiologicalTypeError, AlphabetError, SemanticError,
)

# ── Page Configuration ────────────────────────────────────────────────────────
st.set_page_config(
    page_title="GenomeDSL • Biological Language Studio",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Soft English Heritage Editorial Styling ───────────────────────────────────
# Inspired by traditional British botanical & Oxbridge academic typography:
# Oxford Blue (#1A2738), Cambridge Sage (#4D6A56, #84A98C), English Rose (#8E4452),
# Cotswold Honey (#C4823F), and warm parchment tones (#F7F5F0).
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap');

/* Base Slate Canvas */
html, body,
[data-testid="stAppViewContainer"],
[data-testid="stMain"],
.main .block-container {
    background-color: #121822 !important;
    color: #E2E8F0 !important;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background-color: #161F2C !important;
    border-right: 1px solid rgba(132, 169, 140, 0.15) !important;
}
[data-testid="stSidebar"] * { color: #E2E8F0 !important; }
[data-testid="stSidebar"] hr { border-color: rgba(132, 169, 140, 0.12) !important; }

/* Radio Navigation in Sidebar */
[data-testid="stSidebar"] .stRadio label {
    font-size: 0.94rem !important;
    padding: 8px 12px !important;
    font-weight: 500 !important;
    border-radius: 8px !important;
    transition: all 0.18s ease;
    border: 1px solid transparent;
}
[data-testid="stSidebar"] .stRadio label:hover {
    background: rgba(132, 169, 140, 0.08) !important;
    border-color: rgba(132, 169, 140, 0.2) !important;
}

/* Headings with English Serif Dignity */
h1, h2, h3, .serif-header {
    font-family: 'Cinzel', 'Playfair Display', 'Georgia', 'Baskerville', serif !important;
    letter-spacing: 0.2px;
}

/* Inputs & Textareas */
textarea, .stTextArea textarea {
    background-color: #17212F !important;
    color: #F8FAFC !important;
    border: 1px solid #2B3B4F !important;
    border-radius: 9px !important;
    font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace !important;
    font-size: 0.88rem !important;
    line-height: 1.65 !important;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.25) !important;
}
textarea:focus, .stTextArea textarea:focus {
    border-color: #84A98C !important;
    box-shadow: 0 0 0 1px #84A98C !important;
}

/* Dropdowns & Selects */
[data-testid="stSelectbox"] > div > div {
    background-color: #1A2433 !important;
    color: #E2E8F0 !important;
    border: 1px solid #2D3D52 !important;
    border-radius: 8px !important;
}

/* Buttons */
.stButton > button {
    border-radius: 8px !important;
    font-weight: 600 !important;
    padding: 0.45rem 1.25rem !important;
    font-size: 0.88rem !important;
    transition: all 0.18s ease !important;
    border: 1px solid rgba(255,255,255,0.12) !important;
}
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #4D6A56 0%, #3B5443 100%) !important;
    color: #FAF8F5 !important;
    border: 1px solid #628B6E !important;
    box-shadow: 0 3px 12px rgba(59, 84, 67, 0.35) !important;
}
.stButton > button[kind="primary"]:hover {
    background: linear-gradient(135deg, #5B7D66 0%, #466551 100%) !important;
    box-shadow: 0 5px 16px rgba(59, 84, 67, 0.45) !important;
    transform: translateY(-1px);
}

/* Tabs */
[data-testid="stTabs"] [role="tab"] {
    background: transparent !important;
    color: #94A3B8 !important;
    border-radius: 8px 8px 0 0 !important;
    font-weight: 600 !important;
    font-size: 0.90rem !important;
    padding: 8px 18px !important;
}
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: #D8E2DC !important;
    border-bottom: 2px solid #84A98C !important;
}
[data-testid="stTabs"] [data-testid="stTabPanel"] {
    background: #161F2C !important;
    border: 1px solid rgba(132, 169, 140, 0.14) !important;
    border-radius: 0 10px 10px 10px !important;
    padding: 1.4rem !important;
}

/* Metrics */
[data-testid="stMetric"] {
    background: #17212E !important;
    border: 1px solid #2B3A4D !important;
    border-radius: 9px !important;
    padding: 0.85rem 1.1rem !important;
}

/* Editorial Cards */
.english-hero {
    background: linear-gradient(135deg, #1C2736 0%, #151E2B 100%);
    border: 1px solid rgba(132, 169, 140, 0.22);
    border-left: 5px solid #84A98C;
    border-radius: 11px;
    padding: 1.25rem 1.6rem;
    margin-bottom: 1.3rem;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.card-sage {
    background: rgba(77, 106, 86, 0.12);
    border: 1px solid rgba(132, 169, 140, 0.32);
    border-left: 4px solid #628B6E;
    border-radius: 9px;
    padding: 1rem 1.3rem;
    margin: 0.8rem 0;
    color: #EBF3ED;
}

.card-oxford {
    background: rgba(59, 89, 152, 0.12);
    border: 1px solid rgba(116, 140, 171, 0.32);
    border-left: 4px solid #567AA6;
    border-radius: 9px;
    padding: 1rem 1.3rem;
    margin: 0.8rem 0;
    color: #EEF3F8;
}

.card-rose {
    background: rgba(142, 68, 82, 0.12);
    border: 1px solid rgba(184, 107, 119, 0.32);
    border-left: 4px solid #A65B6A;
    border-radius: 9px;
    padding: 1rem 1.3rem;
    margin: 0.8rem 0;
    color: #F8EDED;
}

.card-honey {
    background: rgba(196, 130, 63, 0.12);
    border: 1px solid rgba(221, 161, 94, 0.32);
    border-left: 4px solid #C4823F;
    border-radius: 9px;
    padding: 1rem 1.3rem;
    margin: 0.8rem 0;
    color: #FAF4EB;
}

.try-box {
    background: #141C27;
    border: 1px solid #28374A;
    border-radius: 9px;
    padding: 1.15rem;
    margin: 1rem 0;
}
.try-title {
    font-size: 0.84rem;
    font-weight: 700;
    letter-spacing: 0.6px;
    text-transform: uppercase;
    color: #84A98C;
    margin-bottom: 0.45rem;
    display: flex;
    align-items: center;
    gap: 7px;
}

/* Hologram Simulation Stage */
.holo-stage {
    background: radial-gradient(circle at 50% 30%, #1A283B 0%, #111721 80%);
    border: 1px solid rgba(132, 169, 140, 0.28);
    border-radius: 12px;
    padding: 1.5rem;
    margin: 1.2rem 0;
    box-shadow: 0 8px 30px rgba(0,0,0,0.35), inset 0 0 25px rgba(132, 169, 140, 0.05);
}

.holo-node {
    background: #182333;
    border: 1px solid #2F4259;
    border-radius: 8px;
    padding: 0.9rem 1.1rem;
    transition: all 0.2s ease;
}
.holo-node:hover {
    border-color: #84A98C;
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(0,0,0,0.25);
}
</style>
""", unsafe_allow_html=True)

# ── Universal Biological Codon Reference ──────────────────────────────────────
CODON_MAP = {
    "UUU": ("Phenylalanine", "Phe", "F", "Hydrophobic / Aromatic"),
    "UUC": ("Phenylalanine", "Phe", "F", "Hydrophobic / Aromatic"),
    "UUA": ("Leucine", "Leu", "L", "Hydrophobic / Aliphatic"),
    "UUG": ("Leucine", "Leu", "L", "Hydrophobic / Aliphatic"),
    "UCU": ("Serine", "Ser", "S", "Polar uncharged"),
    "UCC": ("Serine", "Ser", "S", "Polar uncharged"),
    "UCA": ("Serine", "Ser", "S", "Polar uncharged"),
    "UCG": ("Serine", "Ser", "S", "Polar uncharged"),
    "UAU": ("Tyrosine", "Tyr", "Y", "Polar / Aromatic"),
    "UAC": ("Tyrosine", "Tyr", "Y", "Polar / Aromatic"),
    "UAA": ("STOP (Ochre)", "Stop", "*", "Translation Stop Signal"),
    "UAG": ("STOP (Amber)", "Stop", "*", "Translation Stop Signal"),
    "UGU": ("Cysteine", "Cys", "C", "Polar / Disulfide bridge"),
    "UGC": ("Cysteine", "Cys", "C", "Polar / Disulfide bridge"),
    "UGA": ("STOP (Opal)", "Stop", "*", "Translation Stop Signal"),
    "UGG": ("Tryptophan", "Trp", "W", "Hydrophobic / Aromatic"),
    "CUU": ("Leucine", "Leu", "L", "Hydrophobic / Aliphatic"),
    "CUC": ("Leucine", "Leu", "L", "Hydrophobic / Aliphatic"),
    "CUA": ("Leucine", "Leu", "L", "Hydrophobic / Aliphatic"),
    "CUG": ("Leucine", "Leu", "L", "Hydrophobic / Aliphatic"),
    "CCU": ("Proline", "Pro", "P", "Rigid / Cyclic structure"),
    "CCC": ("Proline", "Pro", "P", "Rigid / Cyclic structure"),
    "CCA": ("Proline", "Pro", "P", "Rigid / Cyclic structure"),
    "CCG": ("Proline", "Pro", "P", "Rigid / Cyclic structure"),
    "CAU": ("Histidine", "His", "H", "Basic / Positively charged"),
    "CAC": ("Histidine", "His", "H", "Basic / Positively charged"),
    "CAA": ("Glutamine", "Gln", "Q", "Polar uncharged"),
    "CAG": ("Glutamine", "Gln", "Q", "Polar uncharged"),
    "CGU": ("Arginine", "Arg", "R", "Basic / Positively charged"),
    "CGC": ("Arginine", "Arg", "R", "Basic / Positively charged"),
    "CGA": ("Arginine", "Arg", "R", "Basic / Positively charged"),
    "CGG": ("Arginine", "Arg", "R", "Basic / Positively charged"),
    "AUU": ("Isoleucine", "Ile", "I", "Hydrophobic / Aliphatic"),
    "AUC": ("Isoleucine", "Ile", "I", "Hydrophobic / Aliphatic"),
    "AUA": ("Isoleucine", "Ile", "I", "Hydrophobic / Aliphatic"),
    "AUG": ("Methionine (START)", "Met", "M", "Start Codon / Hydrophobic"),
    "ACU": ("Threonine", "Thr", "T", "Polar uncharged"),
    "ACC": ("Threonine", "Thr", "T", "Polar uncharged"),
    "ACA": ("Threonine", "Thr", "T", "Polar uncharged"),
    "ACG": ("Threonine", "Thr", "T", "Polar uncharged"),
    "AAU": ("Asparagine", "Asn", "N", "Polar uncharged"),
    "AAC": ("Asparagine", "Asn", "N", "Polar uncharged"),
    "AAA": ("Lysine", "Lys", "K", "Basic / Positively charged"),
    "AAG": ("Lysine", "Lys", "K", "Basic / Positively charged"),
    "AGU": ("Serine", "Ser", "S", "Polar uncharged"),
    "AGC": ("Serine", "Ser", "S", "Polar uncharged"),
    "AGA": ("Arginine", "Arg", "R", "Basic / Positively charged"),
    "AGG": ("Arginine", "Arg", "R", "Basic / Positively charged"),
    "GUU": ("Valine", "Val", "V", "Hydrophobic / Aliphatic"),
    "GUC": ("Valine", "Val", "V", "Hydrophobic / Aliphatic"),
    "GUA": ("Valine", "Val", "V", "Hydrophobic / Aliphatic"),
    "GUG": ("Valine", "Val", "V", "Hydrophobic / Aliphatic"),
    "GCU": ("Alanine", "Ala", "A", "Hydrophobic / Small aliphatic"),
    "GCC": ("Alanine", "Ala", "A", "Hydrophobic / Small aliphatic"),
    "GCA": ("Alanine", "Ala", "A", "Hydrophobic / Small aliphatic"),
    "GCG": ("Alanine", "Ala", "A", "Hydrophobic / Small aliphatic"),
    "GAU": ("Aspartate", "Asp", "D", "Acidic / Negatively charged"),
    "GAC": ("Aspartate", "Asp", "D", "Acidic / Negatively charged"),
    "GAA": ("Glutamate", "Glu", "E", "Acidic / Negatively charged"),
    "GAG": ("Glutamate", "Glu", "E", "Acidic / Negatively charged"),
    "GGU": ("Glycine", "Gly", "G", "Small / Flexible"),
    "GGC": ("Glycine", "Gly", "G", "Small / Flexible"),
    "GGA": ("Glycine", "Gly", "G", "Small / Flexible"),
    "GGG": ("Glycine", "Gly", "G", "Small / Flexible"),
}

# ── Curated Biological Recipes & Presets ──────────────────────────────────────
EXAMPLES = {
    "1. Central Dogma  (DNA → RNA → Protein)": """\
# Complete Central Dogma Pipeline in GenomeDSL
DNA gene = "ATGCGTACCGTA"
RNA transcript = transcribe(gene)
Protein peptide = translate(transcript)
DNA rc = reverse_complement(gene)
RESULT gc = gc_content(gene)
RESULT len_seq = length(gene)

PRINT "DNA sequence:      ", gene
PRINT "Transcribed RNA:   ", transcript
PRINT "Translated Protein:", peptide
PRINT "Reverse Complement:", rc
PRINT "GC Content (%):    ", gc
PRINT "Sequence Length:   ", len_seq

PLOT gc_content(gene)
""",
    "2. Sequence Comparison & Motif Search": """\
# Sequence Comparison and Motif Search
Protein insulin = "GIVEQCCTSICSLYQLENYCN"
DNA seq1 = "ATGCGTAC"
DNA seq2 = "ATGGGTAC"

# Percentage identity calculation
RESULT similarity = compare(seq1, seq2)

# 1-based motif search with overlap support
RESULT motif_locs = find_motif(seq1, "TAC")

PRINT "Insulin A-chain:         ", insulin
PRINT "Sequence 1:              ", seq1
PRINT "Sequence 2:              ", seq2
PRINT "Sequence Similarity (%): ", similarity
PRINT "Motif 'TAC' Coordinates: ", motif_locs
""",
    "3. Human Insulin A-Chain Recipe": """\
# Human Insulin A-Chain: 21 amino acid metabolic hormone
Protein insulin_a = "GIVEQCCTSICSLYQLENYCN"
RESULT chain_len = length(insulin_a)
RESULT cys_positions = find_motif(insulin_a, "C")

PRINT "Insulin A-chain Peptide: ", insulin_a
PRINT "Residue Count (aa):      ", chain_len
PRINT "Cysteine Bridges at (1-based): ", cys_positions
""",
    "4. TATA-Box Core Promoter Scan": """\
# Locating TATA-Box eukaryotic core promoter motifs (TATAAA)
DNA promoter = "GGCCCGTATAAAGGCTATAAACCCGGG"
RESULT tata_hits = find_motif(promoter, "TATAAA")
RESULT promoter_gc = gc_content(promoter)

PRINT "Promoter Region:        ", promoter
PRINT "Promoter GC Content (%):", promoter_gc
PRINT "TATA-box Start Sites:   ", tata_hits
""",
    "5. GC-Content Sliding Window Analysis": """\
# GC-Content Sliding Window Visualization
DNA seq = "ATGCGATCGATCGATCGCGCGCATATATCGATCGATCGATCGATCGCGCTATATAGC"
RESULT gc = gc_content(seq)
RESULT sz = length(seq)

PRINT "Sequence:       ", seq
PRINT "Length (bp):    ", sz
PRINT "GC Content (%): ", gc

PLOT gc_content(seq)
""",
    "6. Reverse Complement & Inversion": """\
# Sequence manipulation operations
DNA seq = "ATGCGATCGTA"
DNA rc  = reverse_complement(seq)
DNA rev = reverse(seq)
RESULT gc_original = gc_content(seq)
RESULT gc_rc       = gc_content(rc)

PRINT "Original:          ", seq
PRINT "Reverse Complement:", rc
PRINT "Reversed:          ", rev
PRINT "GC (original, %):  ", gc_original
PRINT "GC (rev_comp, %):  ", gc_rc
""",
    "7. Error — Invalid DNA Alphabet": """\
# The compiler catches 'U' (Uracil) in a DNA sequence
# and rejects it before execution — no runtime crash!
DNA bad = "AUGCGTAC"
""",
    "8. Error — Invalid Protein Alphabet": """\
# Protein Alphabet Error: 'J' is not a standard amino acid
Protein bad_protein = "MVLSTAZJB"
""",
    "9. Error — Type Mismatch (transcribe on RNA)": """\
# transcribe() is only defined for DNA sequences.
# Passing an RNA sequence is a biological type error.
RNA r = "AUGCCGUAC"
RNA illegal = transcribe(r)
""",
}

# ── Helper Rendering Functions ────────────────────────────────────────────────
def _phase_card(num: str, name: str, status: str, sub: str = "") -> str:
    color_map = {
        "ok":   ("#4D6A56", "#EBF3ED", "rgba(77, 106, 86, 0.25)", "✓ PASS"),
        "err":  ("#8E4452", "#F8EDED", "rgba(142, 68, 82, 0.25)", "✗ FAIL"),
        "warn": ("#C4823F", "#FAF4EB", "rgba(196, 130, 63, 0.25)", "⚡ WARN"),
        "idle": ("#2B3A4D", "#94A3B8", "rgba(43, 58, 77, 0.25)",  "○ IDLE"),
    }
    border, text, bg, badge = color_map.get(status, color_map["idle"])
    sub_html = f'<div style="font-size:0.75rem;color:#94A3B8;margin-top:2px;">{sub}</div>' if sub else ""
    return f"""
    <div style="background:{bg};border:1px solid {border};border-radius:8px;padding:9px 12px;margin-bottom:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="font-size:0.75rem;font-weight:700;color:#94A3B8;">PHASE {num}</span>
        <span style="font-size:0.73rem;font-weight:700;color:{text};background:{border};padding:1px 6px;border-radius:4px;">{badge}</span>
      </div>
      <div style="font-weight:700;font-size:0.92rem;color:#F8FAFC;margin-top:2px;">{name}</div>
      {sub_html}
    </div>
    """

def _terminal(text: str, color: str = "#E2E8F0") -> str:
    escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f"""
    <div style="background:#0F151E;border:1px solid #253346;border-radius:8px;padding:12px 16px;
                font-family:'JetBrains Mono','Consolas',monospace;font-size:0.84rem;
                color:{color};line-height:1.65;white-space:pre-wrap;overflow-x:auto;">
{escaped}
    </div>
    """

def _err_box(title: str, body: str) -> str:
    escaped = body.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f"""
    <div class="card-rose" style="margin-top:0.8rem;">
      <div style="font-weight:700;font-size:0.95rem;color:#FCA5A5;margin-bottom:4px;">{title}</div>
      <div style="font-family:'JetBrains Mono',monospace;font-size:0.84rem;color:#F8EDED;white-space:pre-wrap;">{escaped}</div>
    </div>
    """

def _type_badge(t: str) -> str:
    t_clean = t.upper()
    if t_clean == "DNA":
        return '<span style="background:#203328;color:#A5C4AC;border:1px solid #4D6A56;padding:2px 7px;border-radius:4px;font-size:0.76rem;font-weight:700;">DNA</span>'
    elif t_clean == "RNA":
        return '<span style="background:#1B2B3E;color:#99BFEB;border:1px solid #567AA6;padding:2px 7px;border-radius:4px;font-size:0.76rem;font-weight:700;">RNA</span>'
    elif t_clean in ("PROTEIN", "PEPTIDE"):
        return '<span style="background:#332027;color:#D49A9B;border:1px solid #8E4452;padding:2px 7px;border-radius:4px;font-size:0.76rem;font-weight:700;">Protein</span>'
    else:
        return f'<span style="background:#2C261B;color:#F0D290;border:1px solid #C4823F;padding:2px 7px;border-radius:4px;font-size:0.76rem;font-weight:700;">{t}</span>'

def _section(title: str) -> str:
    return f"""
    <div style="font-family:'Cinzel','Georgia',serif;font-size:0.84rem;font-weight:700;letter-spacing:1px;
                color:#84A98C;margin:1.4rem 0 0.6rem;text-transform:uppercase;border-bottom:1px solid rgba(132, 169, 140, 0.2);padding-bottom:4px;">
      {title}
    </div>
    """

# ── Session State Initialization ──────────────────────────────────────────────
if "app_nav" not in st.session_state:
    st.session_state["app_nav"] = "🔬 Studio & IDE"

# Permanent plot path fallback
plot_fallback = os.path.join(os.path.dirname(__file__), "evidence", "gc_profile.png")
if "active_plot_path" not in st.session_state:
    st.session_state["active_plot_path"] = plot_fallback if os.path.exists(plot_fallback) else ""

# ── Sidebar Navigation ────────────────────────────────────────────────────────
PAGES = [
    "🔬 Studio & IDE",
    "✨ Compiler & Hologram Simulator",
    "📖 Beginner Academy & Practice Ground",
    "🧪 Molecular Sandbox & Codon Tools",
]

with st.sidebar:
    st.markdown(
        '<div style="font-family:\'Cinzel\', serif; font-size:1.45rem;font-weight:700;letter-spacing:0.3px;color:#F7F5F0;">'
        '🧬 GenomeDSL</div>'
        '<div style="font-size:0.8rem;color:#84A98C;margin-bottom:1rem;font-style:italic;">'
        'Biological Programming Language Studio</div>',
        unsafe_allow_html=True,
    )
    st.divider()

    nav_index = PAGES.index(st.session_state["app_nav"]) if st.session_state["app_nav"] in PAGES else 0
    nav = st.radio(
        "Navigation",
        PAGES,
        index=nav_index,
        label_visibility="collapsed",
    )
    st.session_state["app_nav"] = nav

    st.divider()

    st.markdown(
        '<div style="font-size:0.78rem;color:#CBD5E1;line-height:1.7;">'
        '<b style="color:#F7F5F0;font-family:\'Cinzel\',serif;">Core Biological Types</b><br>'
        '🌿 <b>DNA</b> &bull; 🌊 <b>RNA</b> &bull; 🌸 <b>Protein</b> &bull; 🍑 <b>RESULT</b>'
        '</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div style="font-size:0.78rem;color:#94A3B8;margin-top:0.8rem;line-height:1.85;">'
        '<b style="color:#F7F5F0;font-family:\'Cinzel\',serif;">Built-in Operations</b><br>'
        '<code style="color:#84A98C;">transcribe()</code><br>'
        '<code style="color:#84A98C;">translate()</code><br>'
        '<code style="color:#84A98C;">reverse_complement()</code><br>'
        '<code style="color:#84A98C;">reverse()</code><br>'
        '<code style="color:#84A98C;">gc_content()</code><br>'
        '<code style="color:#84A98C;">length()</code><br>'
        '<code style="color:#84A98C;">compare()</code><br>'
        '<code style="color:#84A98C;">find_motif()</code><br>'
        '</div>',
        unsafe_allow_html=True,
    )
    st.divider()
    st.markdown(
        '<div style="font-size:0.72rem;color:#64748B;line-height:1.5;">'
        'Department of Computational Biology &bull; Oxford-style Academic Edition &bull; 33/33 Tests Passing'
        '</div>',
        unsafe_allow_html=True,
    )


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — STUDIO & IDE (With Restored, Permanent Visual Graph)
# ══════════════════════════════════════════════════════════════════════════════
if nav == "🔬 Studio & IDE":
    # Welcoming Oxford/Cambridge editorial banner
    col_banner_txt, col_banner_btn = st.columns([3.8, 1.2])
    with col_banner_txt:
        st.markdown("""
        <div class="english-hero" style="margin-bottom:0.8rem; padding:1.1rem 1.4rem;">
          <div style="font-family:'Cinzel', serif; font-weight: 700; font-size: 1.05rem; color: #D8E2DC;">
            🏛️ Welcome to the GenomeDSL Biological Studio
          </div>
          <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 4px;">
            A rigorous, beginner-friendly domain-specific environment for genomic computing.
            Write or load biological programs, inspect compiler passes in real-time, and analyze publication-grade visual profiles.
          </div>
        </div>
        """, unsafe_allow_html=True)
    with col_banner_btn:
        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        if st.button("📖 Open Academy →", key="btn_open_academy_hero", use_container_width=True):
            st.session_state["app_nav"] = "📖 Beginner Academy & Practice Ground"
            st.rerun()

    col_sel, col_opt = st.columns([3, 1])
    with col_sel:
        preset_names = list(EXAMPLES.keys())
        if "active_code" in st.session_state:
            options_list = ["💡 [Loaded from Tutorial/Challenge/Sandbox]"] + preset_names
        else:
            options_list = preset_names

        sel = st.selectbox("Curated Biological Recipe:", options_list, label_visibility="collapsed")
    with col_opt:
        opt_on = st.toggle("AST Optimizer", value=True)

    # Determine editor content
    if sel == "💡 [Loaded from Tutorial/Challenge/Sandbox]" and "active_code" in st.session_state:
        current_code = st.session_state["active_code"]
    else:
        current_code = EXAMPLES.get(sel, EXAMPLES[preset_names[0]])

    code = st.text_area(
        "Source Code",
        value=current_code,
        height=220,
        label_visibility="collapsed",
    )

    run = st.button("▶  Compile & Execute Program", type="primary", use_container_width=True)

    # Track execution data in session state so results and visual graphs persist across widget changes
    if run and code.strip():
        phases  = {"parse": "idle", "sem": "idle", "opt": "idle", "exec": "idle"}
        parsed  = sym = opt_ast = bk = None
        err_html = ""
        opt_stats = {"constant_folds": 0, "reversible_reductions": 0}
        opt_label = ""

        # 1. Parse Phase
        try:
            parsed = parse_code(code)
            phases["parse"] = "ok"
        except GenomeDSLError as e:
            phases["parse"] = "err"
            err_html = _err_box("Syntax / Lexical Error", e.format_error())

        # 2. Semantic Analysis Phase
        if parsed:
            try:
                sym = analyze_code(parsed)
                phases["sem"] = "ok"
            except AlphabetError as e:
                phases["sem"] = "err"
                err_html = _err_box("Biological Alphabet Error", e.format_error())
            except BiologicalTypeError as e:
                phases["sem"] = "err"
                err_html = _err_box("Biological Type Error", e.format_error())
            except GenomeDSLError as e:
                phases["sem"] = "err"
                err_html = _err_box("Semantic Error", e.format_error())

        # 3. Optimization Phase
        if sym:
            if opt_on:
                try:
                    _o = ASTOptimizer()
                    opt_ast = _o.optimize(parsed)
                    opt_stats = _o.stats
                    opt_label = f"{opt_stats['constant_folds']} folds · {opt_stats['reversible_reductions']} red."
                    phases["opt"] = "ok"
                except Exception:
                    opt_ast = parsed
                    phases["opt"] = "warn"
                    opt_label = "partial"
            else:
                opt_ast = parsed
                phases["opt"] = "idle"
                opt_label = "skipped"

        # 4. Backend Execution
        saved_plots = []
        if opt_ast and sym:
            evidence_dir = os.path.join(os.path.dirname(__file__), "evidence")
            os.makedirs(evidence_dir, exist_ok=True)
            bk = ExecutionBackend(visual_output_dir=evidence_dir)
            try:
                bk.execute(opt_ast)
                phases["exec"] = "ok"
                for p in bk.generated_plots:
                    if os.path.exists(p):
                        saved_plots.append(p)
                        st.session_state["active_plot_path"] = p
            except GenomeDSLError as e:
                phases["exec"] = "err"
                err_html = _err_box("Runtime Execution Error", e.format_error())
                bk = None

        st.session_state["last_phases"] = phases
        st.session_state["last_parsed"] = parsed
        st.session_state["last_sym"] = sym
        st.session_state["last_bk"] = bk
        st.session_state["last_err"] = err_html
        st.session_state["last_opt_label"] = opt_label

    # Display Phase Indicator Cards if an execution has occurred
    if "last_phases" in st.session_state:
        phases = st.session_state["last_phases"]
        parsed = st.session_state.get("last_parsed")
        sym = st.session_state.get("last_sym")
        bk = st.session_state.get("last_bk")
        err_html = st.session_state.get("last_err", "")
        opt_label = st.session_state.get("last_opt_label", "")

        sub_vals = [
            f"{len(parsed.statements)} stmts" if phases["parse"] == "ok" and parsed else "",
            f"{len(sym.all_symbols())} symbols" if phases["sem"] == "ok" and sym else "",
            opt_label,
            f"{len(bk.env)} vars" if phases["exec"] == "ok" and bk else "",
        ]
        ph_labels = ["1. Lex & Parse", "2. Semantic Check",
                     "3. AST Optimizer" if opt_on else "3. Optimizer (off)", "4. Execute"]
        ph_nums   = ["01", "02", "03", "04"]
        ph_keys   = ["parse", "sem", "opt", "exec"]

        st.markdown("<div style='height:8px;'></div>", unsafe_allow_html=True)
        cols = st.columns(4)
        for col, num, label, key, sub in zip(cols, ph_nums, ph_labels, ph_keys, sub_vals):
            col.markdown(_phase_card(num, label, phases[key], sub), unsafe_allow_html=True)

        if err_html:
            st.markdown(err_html, unsafe_allow_html=True)

        if bk:
            st.markdown(_section("PROGRAM RESULTS & RUNTIME ENVIRONMENT"), unsafe_allow_html=True)
            col_out, col_env = st.columns([1, 1])

            with col_out:
                st.markdown("**Console Output (stdout)**")
                if bk.stdout:
                    st.markdown(_terminal("\n".join(bk.stdout)), unsafe_allow_html=True)
                else:
                    st.markdown(_terminal("(Program terminated with code 0; zero PRINT statements invoked)", "#94A3B8"), unsafe_allow_html=True)

            with col_env:
                st.markdown("**Environment Symbol Registry**")
                if bk.env:
                    rows = "".join(
                        f'<tr>'
                        f'<td style="padding:7px 11px;border-bottom:1px solid #233144;">'
                        f'<code style="color:#84A98C;">{name}</code></td>'
                        f'<td style="padding:7px 11px;border-bottom:1px solid #233144;">'
                        f'{_type_badge(t)}</td>'
                        f'<td style="padding:7px 11px;border-bottom:1px solid #233144;'
                        f'color:#F8FAFC;font-family:monospace;font-size:0.83rem;">'
                        f'{"&quot;" + str(v) + "&quot;" if isinstance(v, str) else str(v)}'
                        f'</td></tr>'
                        for name, (v, t) in bk.env.items()
                    )
                    st.markdown(
                        f'<table style="width:100%;border-collapse:collapse;'
                        f'background:#161F2C;border-radius:8px;overflow:hidden;border:1px solid rgba(132, 169, 140, 0.16);">'
                        f'<thead><tr>'
                        f'<th style="background:#1F2A3B;color:#94A3B8;padding:8px 11px;text-align:left;font-size:0.77rem;letter-spacing:0.5px;">IDENTIFIER</th>'
                        f'<th style="background:#1F2A3B;color:#94A3B8;padding:8px 11px;text-align:left;font-size:0.77rem;letter-spacing:0.5px;">TYPE</th>'
                        f'<th style="background:#1F2A3B;color:#94A3B8;padding:8px 11px;text-align:left;font-size:0.77rem;letter-spacing:0.5px;">VALUE</th>'
                        f'</tr></thead><tbody>{rows}</tbody></table>',
                        unsafe_allow_html=True,
                    )

    # ── PERMANENT RESTORED VISUAL GRAPH PANEL ───────────────────────────────────
    st.markdown(_section("📊 DUAL-PANEL GENOMIC PROFILE & NUCLEOTIDE COMPOSITION"), unsafe_allow_html=True)

    col_graph_ctrl, col_graph_view = st.columns([1.1, 2.9])

    with col_graph_ctrl:
        st.markdown("""
        <div class="card-sage" style="margin-top:0;">
          <div style="font-weight:700;font-size:0.88rem;color:#D8E2DC;margin-bottom:4px;">
            Sliding-Window Profiler
          </div>
          <div style="font-size:0.8rem;color:#CBD5E1;line-height:1.5;">
            Calculates rolling GC% density across the sequence coordinates and breaks down base frequencies.
          </div>
        </div>
        """, unsafe_allow_html=True)

        w_size = st.slider("Window Size (bp):", min_value=3, max_value=40, value=8, step=1)
        w_step = st.slider("Step Size (bp):", min_value=1, max_value=5, value=1, step=1)

        # Allow user to pick which sequence from the current code/env to visualize
        env_dna_vars = {}
        if "last_bk" in st.session_state and st.session_state["last_bk"] and st.session_state["last_bk"].env:
            for k, (val, t_name) in st.session_state["last_bk"].env.items():
                if t_name in ("DNA", "RNA") and isinstance(val, str) and len(val) >= 4:
                    env_dna_vars[k] = val

        if env_dna_vars:
            chosen_var = st.selectbox("Select Sequence to Re-Plot:", list(env_dna_vars.keys()))
            target_seq = env_dna_vars[chosen_var]
        else:
            target_seq = "ATGCGATCGATCGATCGCGCGCATATATCGATCGATCGATCGATCGCGCTATATAGC"
            chosen_var = "Lambda Phage Segment (Preset)"

        if st.button("🔄 Update / Re-Plot Visual Graph", key="btn_replot", use_container_width=True):
            evidence_dir = os.path.join(os.path.dirname(__file__), "evidence")
            os.makedirs(evidence_dir, exist_ok=True)
            custom_plot = os.path.join(evidence_dir, "gc_profile.png")
            plot_gc_content_window(
                sequence=target_seq,
                title=f"GC-Content Profile: {chosen_var} (window={w_size}bp)",
                window_size=w_size,
                output_dir=evidence_dir,
                filename="gc_profile.png",
            )
            st.session_state["active_plot_path"] = custom_plot
            st.success("Visual graph updated successfully!")

    with col_graph_view:
        active_plot = st.session_state.get("active_plot_path", "")
        if active_plot and os.path.exists(active_plot):
            st.image(active_plot, use_container_width=True, caption="Figure 1: Dual-Panel Sliding Window GC% Profile & Nucleotide Frequency Distribution")
        else:
            # Fallback generation on the fly so it is NEVER missing
            fallback_img = os.path.join(os.path.dirname(__file__), "evidence", "gc_profile.png")
            if not os.path.exists(fallback_img):
                evidence_dir = os.path.join(os.path.dirname(__file__), "evidence")
                os.makedirs(evidence_dir, exist_ok=True)
                plot_gc_content_window(
                    sequence="ATGCGATCGATCGATCGCGCGCATATATCGATCGATCGATCGATCGCGCTATATAGC",
                    title="GC-Content Sliding Window Profile: Reference Genome",
                    window_size=8,
                    output_dir=evidence_dir,
                    filename="gc_profile.png",
                )
            st.session_state["active_plot_path"] = fallback_img
            st.image(fallback_img, use_container_width=True, caption="Figure 1: Reference Genome GC% Profile (Lambda Phage Segment)")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — COMPILER & HOLOGRAM SIMULATOR
# ══════════════════════════════════════════════════════════════════════════════
elif nav == "✨ Compiler & Hologram Simulator":
    st.markdown("""
    <div class="english-hero">
      <div style="font-size:0.78rem; font-weight:700; letter-spacing:1px; color:#84A98C; text-transform:uppercase;">
        Interactive Visualization &bull; Compiler Machinery &amp; Molecular Stage
      </div>
      <div style="font-family:'Cinzel', serif; font-size:1.85rem; font-weight:700; color:#F7F5F0; margin:0.3rem 0;">
        How GenomeDSL Works: Inside the Compiler Pipeline
      </div>
      <div style="font-size:0.92rem; color:#CBD5E1; max-width:880px; line-height:1.6;">
        Explore the multi-phase architecture of our biological language. Step through how raw source code is
        lexically scanned by Lark, transformed into typed AST nodes, verified against the Central Dogma,
        algebraically optimized, and synthesized through Biopython.
      </div>
    </div>
    """, unsafe_allow_html=True)

    tab_compiler_sim, tab_molecular_holo = st.tabs([
        "🔬 Interactive Compiler Pipeline Simulator",
        "🧬 3D Central Dogma Holographic Stage",
    ])

    # ── TAB 1: STEP-BY-STEP COMPILER SIMULATION ──
    with tab_compiler_sim:
        st.markdown("### Step-by-Step Compilation Walkthrough")
        st.markdown("Select a sample biological statement to simulate its passage through the 5 compiler phases:")

        sample_choice = st.selectbox(
            "Select Compilation Scenario:",
            [
                "Scenario A: Valid Central Dogma (DNA -> RNA -> Protein)",
                "Scenario B: Constant Folding & Reversible Reduction Optimization",
                "Scenario C: Compile-Time Alphabet Error Interception ('U' in DNA)",
                "Scenario D: Biological Type Mismatch (transcribing RNA)",
            ],
            index=0
        )

        scenario_code_map = {
            "Scenario A: Valid Central Dogma (DNA -> RNA -> Protein)": 'DNA gene = "ATGCGTACCGTA"\nRNA mrna = transcribe(gene)\nProtein peptide = translate(mrna)\nPRINT peptide',
            "Scenario B: Constant Folding & Reversible Reduction Optimization": 'DNA seq = "ATGC"\nDNA opt = reverse_complement(reverse_complement(seq))\nRESULT c_len = length("ATGC")\nRESULT c_gc = gc_content("GCGC")',
            "Scenario C: Compile-Time Alphabet Error Interception ('U' in DNA)": 'DNA invalid = "AUGCGTAC"\nPRINT invalid',
            "Scenario D: Biological Type Mismatch (transcribing RNA)": 'RNA transcript = "AUGCCGUAC"\nRNA illegal = transcribe(transcript)',
        }

        sim_code = scenario_code_map[sample_choice]

        st.code(sim_code, language="python")

        # Step controller
        step = st.radio(
            "Compiler Phase:",
            [
                "1. Lexical Tokenization (Lark Scanner)",
                "2. Earley Parsing & Concrete Syntax Tree",
                "3. ASTBuilder & Typed Dataclasses",
                "4. Semantic Verification & Central Dogma",
                "5. Algebraic AST Optimization",
                "6. Biopython Runtime Synthesis & Output",
            ],
            horizontal=True
        )

        st.markdown("<br>", unsafe_allow_html=True)

        if step.startswith("1."):
            st.markdown("""
            <div class="card-oxford">
              <b>Phase 1: Lexical Tokenization</b><br>
              The <code>Lark</code> lexer matches regular expressions defined in <code>grammar.py</code> and generates a stream of discrete tokens.
              Notice how sequence literals are identified by type-specific regex rules (e.g. <code>DNA_LITERAL: /"[ACGTacgt]+"/</code>).
            </div>
            """, unsafe_allow_html=True)

            tokens_preview = [
                ("KW_DNA", "DNA"), ("IDENTIFIER", "gene"), ("ASSIGN", "="), ("DNA_LITERAL", '"ATGCGTACCGTA"'),
                ("KW_RNA", "RNA"), ("IDENTIFIER", "mrna"), ("ASSIGN", "="), ("FUNC_TRANSCRIBE", "transcribe"),
                ("LPAREN", "("), ("IDENTIFIER", "gene"), ("RPAREN", ")")
            ]
            cols = st.columns(len(tokens_preview[:6]))
            for c, (tok_t, tok_v) in zip(cols, tokens_preview[:6]):
                c.markdown(f"""
                <div class="holo-node" style="text-align:center;">
                  <span style="font-size:0.72rem;color:#84A98C;font-weight:700;">{tok_t}</span><br>
                  <code style="color:#F8FAFC;font-size:0.88rem;">{tok_v}</code>
                </div>
                """, unsafe_allow_html=True)

        elif step.startswith("2."):
            st.markdown("""
            <div class="card-oxford">
              <b>Phase 2: Earley Grammar Parsing</b><br>
              Lark parses the token stream against the EBNF grammar. The Earley algorithm guarantees parsing of any context-free grammar
              without left-recursion issues.
            </div>
            """, unsafe_allow_html=True)
            st.code("""
ParseTree(
  'var_decl', [
    Token('KW_DNA', 'DNA'),
    Token('IDENTIFIER', 'gene'),
    Token('DNA_LITERAL', '"ATGCGTACCGTA"')
  ]
)
            """, language="python")

        elif step.startswith("3."):
            st.markdown("""
            <div class="card-sage">
              <b>Phase 3: ASTBuilder Transformer</b><br>
              The <code>ASTBuilder(Transformer)</code> in <code>genomedsl/parser.py</code> traverses the parse tree bottom-up,
              instantiating strongly-typed Python dataclass nodes defined in <code>genomedsl/ast_nodes.py</code>.
            </div>
            """, unsafe_allow_html=True)
            try:
                parsed_node = parse_code(sim_code)
                st.code(parsed_node.pretty(), language="text")
            except Exception as e:
                st.warning(f"Parse error caught by compiler: {e}")

        elif step.startswith("4."):
            st.markdown("""
            <div class="card-rose">
              <b>Phase 4: Semantic Analysis &amp; Central Dogma Enforcement</b><br>
              The <code>SemanticAnalyzer</code> checks biological invariants:
              <ul style="margin-top:6px;">
                <li>Does the sequence contain only valid chemical bases for its declared type?</li>
                <li>Does <code>transcribe()</code> receive only double-stranded <code>DNA</code>?</li>
                <li>Does <code>translate()</code> receive only messenger <code>RNA</code>?</li>
                <li>Are identifiers declared in the <code>SymbolTable</code> before use?</li>
              </ul>
            </div>
            """, unsafe_allow_html=True)
            try:
                p_ast = parse_code(sim_code)
                sym_res = analyze_code(p_ast)
                st.success(f"✓ Semantic verification passed! {len(sym_res.all_symbols())} biological symbols registered.")
                for s_name, s_obj in sym_res.all_symbols().items():
                    st.markdown(f"&bull; Symbol `'{s_name}'`: Biological Type `{s_obj.type_name}` (Line {s_obj.line})")
            except GenomeDSLError as e:
                st.markdown(_err_box("Compile-Time Semantic Interception", e.format_error()), unsafe_allow_html=True)

        elif step.startswith("5."):
            st.markdown("""
            <div class="card-honey">
              <b>Phase 5: AST Optimizer</b><br>
              The <code>ASTOptimizer</code> walks the AST looking for algebraic identities:
              <ul style="margin-top:6px;">
                <li><b>Constant Folding:</b> Evaluates <code>length("ATGC") &rarr; 4</code> and <code>gc_content("GCGC") &rarr; 100.0</code> at compile time.</li>
                <li><b>Reversible Operation Elimination:</b> Cancels out inverse transformations: <code>reverse_complement(reverse_complement(x)) &rarr; x</code> and <code>reverse(reverse(x)) &rarr; x</code>.</li>
              </ul>
            </div>
            """, unsafe_allow_html=True)
            try:
                p_ast = parse_code(sim_code)
                opt = ASTOptimizer()
                reduced = opt.optimize(p_ast)
                st.markdown(f"**Optimization Reductions Applied:** `{opt.stats['constant_folds']} constant folds` &bull; `{opt.stats['reversible_reductions']} reversible reductions`")
                col_b, col_a = st.columns(2)
                with col_b:
                    st.caption("AST Before Optimization:")
                    st.code(p_ast.pretty(), language="text")
                with col_a:
                    st.caption("AST After Optimization:")
                    st.code(reduced.pretty(), language="text")
            except Exception as e:
                st.info(f"Optimization skipped due to prior diagnostic: {e}")

        elif step.startswith("6."):
            st.markdown("""
            <div class="card-sage">
              <b>Phase 6: Biopython Runtime Synthesis</b><br>
              The <code>ExecutionBackend</code> executes the optimized AST nodes using <code>Bio.Seq</code>.
              Outputs are piped to the console and visualizations are rendered via <code>Matplotlib</code>.
            </div>
            """, unsafe_allow_html=True)
            try:
                p_ast = parse_code(sim_code)
                analyze_code(p_ast)
                opt = ASTOptimizer()
                reduced = opt.optimize(p_ast)
                bk = ExecutionBackend()
                bk.execute(reduced)
                st.success("Execution completed successfully!")
                st.markdown("**Program stdout:**")
                st.markdown(_terminal("\n".join(bk.stdout)), unsafe_allow_html=True)
            except GenomeDSLError as e:
                st.markdown(_err_box("Runtime / Interception Halt", e.format_error()), unsafe_allow_html=True)

    # ── TAB 2: HOLOGRAPHIC MOLECULAR STAGE ──
    with tab_molecular_holo:
        st.markdown("### 3D Holographic Molecular Central Dogma Stage")
        st.markdown("Interact with the virtual molecular synthesizer. Enter any DNA sequence and watch the simulated biological machinery transcribe and translate in real-time:")

        col_inp, col_presets = st.columns([3, 1.5])
        with col_presets:
            st.markdown("<div style='height:4px;'></div>", unsafe_allow_html=True)
            preset_mol = st.selectbox(
                "Biological Presets:",
                ["Human Insulin Gene", "Sickle Cell Normal HbA", "Sickle Cell Mutant HbS", "GFP Fluorophore Motif"]
            )
            preset_map = {
                "Human Insulin Gene": "ATGCGTACCGTA",
                "Sickle Cell Normal HbA": "GTGCACCTGACTCCTGAGGAG",
                "Sickle Cell Mutant HbS": "GTGCACCTGACTCCTGTGGAG",
                "GFP Fluorophore Motif": "AGCAAAGGAGAAGAACTTTTCACT",
            }

        with col_inp:
            active_seq = st.text_input("Enter DNA Coding Strand (5' -> 3'):", value=preset_map[preset_mol]).upper().strip()

        # Validate DNA sequence
        is_valid_dna = all(c in "ATGC" for c in active_seq) and len(active_seq) > 0

        if not is_valid_dna:
            st.error("Please enter a valid DNA sequence containing only nucleotides A, T, G, and C.")
        else:
            # Biochemical calculations
            complementary_dna = "".join({"A": "T", "T": "A", "G": "C", "C": "G"}.get(b, "?") for b in active_seq)
            mrna_transcript = active_seq.replace("T", "U")

            # Codon grouping & translation
            codons = [mrna_transcript[i:i+3] for i in range(0, len(mrna_transcript), 3)]
            aa_residues = []
            for c in codons:
                if len(c) == 3:
                    info = CODON_MAP.get(c, ("Unknown", "Unk", "?", "Custom"))
                    aa_residues.append(info[2])
                else:
                    aa_residues.append(f"({c})")
            polypeptide_str = "".join(aa_residues)

            gc_pct = round(((active_seq.count("G") + active_seq.count("C")) / len(active_seq)) * 100.0, 1)

            st.markdown("""
            <div class="holo-stage">
              <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(132, 169, 140, 0.25); padding-bottom:8px; margin-bottom:14px;">
                <span style="font-family:'Cinzel',serif; font-size:1.1rem; color:#D8E2DC; font-weight:700;">
                  ✨ Virtual Molecular Simulation Matrix
                </span>
                <span style="background:#203328; color:#A5C4AC; border:1px solid #4D6A56; padding:3px 10px; border-radius:5px; font-size:0.78rem; font-weight:700;">
                  HOLOGRAPHIC STATUS: ACTIVE
                </span>
              </div>

              <!-- Stage 1: DNA Double Helix -->
              <div style="margin-bottom:16px;">
                <div style="font-size:0.8rem; font-weight:700; color:#84A98C; letter-spacing:0.5px; text-transform:uppercase;">
                  Stage 1: Double-Stranded DNA Helix Unwinding (Hydrogen Bonds)
                </div>
                <div style="font-family:'JetBrains Mono',monospace; font-size:0.95rem; margin-top:6px; background:#0F1620; padding:12px; border-radius:8px; border:1px solid #24354A;">
                  <span style="color:#94A3B8;">5'- </span><span style="color:#A5C4AC; font-weight:700;">{active_seq}</span><span style="color:#94A3B8;"> -3' (Coding Strand)</span><br>
                  <span style="color:#52796F; letter-spacing:2px;">{'   |' * len(active_seq)}</span><br>
                  <span style="color:#94A3B8;">3'- </span><span style="color:#748CAB; font-weight:700;">{complementary_dna}</span><span style="color:#94A3B8;"> -5' (Template Strand)</span>
                </div>
              </div>

              <!-- Stage 2: Transcription Bubble -->
              <div style="margin-bottom:16px;">
                <div style="font-size:0.8rem; font-weight:700; color:#748CAB; letter-spacing:0.5px; text-transform:uppercase;">
                  Stage 2: RNA Polymerase Transcription Bubble (T &rarr; U)
                </div>
                <div style="font-family:'JetBrains Mono',monospace; font-size:0.95rem; margin-top:6px; background:#0F1620; padding:12px; border-radius:8px; border:1px solid #24354A;">
                  <span style="color:#94A3B8;">mRNA 5'- </span>
                  <span style="color:#99BFEB; font-weight:700; letter-spacing:1px;">{' · '.join(codons)}</span>
                  <span style="color:#94A3B8;"> -3' (Messenger Transcript)</span>
                </div>
              </div>

              <!-- Stage 3: Ribosomal Translation -->
              <div>
                <div style="font-size:0.8rem; font-weight:700; color:#D49A9B; letter-spacing:0.5px; text-transform:uppercase;">
                  Stage 3: Ribosome Complex Polypeptide Synthesis
                </div>
                <div style="font-family:'JetBrains Mono',monospace; font-size:0.95rem; margin-top:6px; background:#0F1620; padding:12px; border-radius:8px; border:1px solid #24354A;">
                  <span style="color:#94A3B8;">N-terminus [ </span>
                  <span style="color:#FCA5A5; font-weight:700; letter-spacing:2px;">{' - '.join(aa_residues)}</span>
                  <span style="color:#94A3B8;"> ] C-terminus</span>
                </div>
              </div>
            </div>
            """.format(active_seq=active_seq, complementary_dna=complementary_dna), unsafe_allow_html=True)

            col_m1, col_m2, col_m3 = st.columns(3)
            col_m1.metric("Sequence Length", f"{len(active_seq)} bp")
            col_m2.metric("GC-Density Index", f"{gc_pct}%")
            col_m3.metric("Synthesized Polypeptide", polypeptide_str)

            # Generate GenomeDSL code snippet to solve this in the studio
            sim_gdsl = f'# Generated from Holographic Molecular Synthesizer\nDNA gene = "{active_seq}"\nRNA transcript = transcribe(gene)\nProtein peptide = translate(transcript)\nRESULT gc = gc_content(gene)\n\nPRINT "Synthesized Peptide: ", peptide\nPRINT "Thermodynamic GC:   ", gc\nPLOT gc_content(gene)'

            if st.button("🚀 Load Synthesized Hologram Pipeline into Studio IDE", key="btn_load_holo", type="primary"):
                st.session_state["active_code"] = sim_gdsl
                st.session_state["app_nav"] = "🔬 Studio & IDE"
                st.rerun()


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — BEGINNER ACADEMY & PRACTICE GROUND
# ══════════════════════════════════════════════════════════════════════════════
elif nav == "📖 Beginner Academy & Practice Ground":
    st.markdown("""
    <div class="english-hero">
      <div style="font-size:0.78rem; font-weight:700; letter-spacing:1px; color:#84A98C; text-transform:uppercase;">
        Comprehensive Learning Academy &bull; Reference &amp; Hands-on Practice
      </div>
      <div style="font-family:'Cinzel', serif; font-size:1.85rem; font-weight:700; color:#F7F5F0; margin:0.3rem 0;">
        Beginner Academy &amp; Compiler Mastery
      </div>
      <div style="font-size:0.92rem; color:#CBD5E1; max-width:880px; line-height:1.6;">
        Master the architecture of domain-specific languages and computational biology. Explore how the Lark parser,
        Biopython engine, and Matplotlib visualizer collaborate, learn the formal language rules, and solve 12 guided challenges.
      </div>
    </div>
    """, unsafe_allow_html=True)

    tab_compiler_coding, tab_packages, tab_rules, tab_challenges = st.tabs([
        "🏛️ The Compiler Coding Part & Architecture",
        "📦 Platform Packages (Lark, Biopython, Matplotlib)",
        "📜 Complete DSL Language Rules & Syntax",
        "🎯 12 Interactive Practice Challenges",
    ])

    # ── TAB 1: COMPILER ARCHITECTURE DEEP-DIVE ──
    with tab_compiler_coding:
        st.markdown("### The GenomeDSL Compiler Architecture")
        st.markdown("""
        Unlike general-purpose programming languages where biological sequences are represented as untyped strings,
        **GenomeDSL implements a fully dedicated, multi-pass compiler pipeline** designed specifically to enforce biological correctness.
        """)

        # Embed local SVG compiler pipeline
        pipeline_svg_path = os.path.join(os.path.dirname(__file__), "assets", "compiler_pipeline.svg")
        if os.path.exists(pipeline_svg_path):
            with open(pipeline_svg_path, "r", encoding="utf-8") as f:
                st.markdown(f.read(), unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("""
        #### Detailed Compiler Module Breakdown:

        <div class="card-oxford">
          <b>1. Grammar Specification (<code>genomedsl/grammar.py</code>)</b><br>
          Written in Extended Backus-Naur Form (EBNF) for the <code>Lark</code> parser engine. Defines distinct terminal tokens
          with biological regex patterns:
          <ul>
            <li><code>DNA_LITERAL: /"[ACGTacgt]+"/</code> &bull; Matches double-stranded DNA only.</li>
            <li><code>RNA_LITERAL: /"[ACGUacgu]+"/</code> &bull; Matches single-stranded RNA only.</li>
            <li><code>PROTEIN_LITERAL: /"[ACDEFGHIKLMNPQRSTVWYacdefghiklmnpqrstvwy*]+"/</code> &bull; Matches the 20 standard IUPAC amino acids + stop signal (<code>*</code>).</li>
          </ul>
        </div>

        <div class="card-sage">
          <b>2. Earley Parser &amp; ASTBuilder (<code>genomedsl/parser.py</code>)</b><br>
          Uses Lark's Earley parsing algorithm to construct a Concrete Syntax Tree (CST). An <code>ASTBuilder(Transformer)</code>
          walks the parse tree bottom-up, converting raw tokens into typed Python dataclasses:
          <ul>
            <li><code>ProgramNode</code>: Root node holding a list of statements.</li>
            <li><code>VarDeclNode</code>: Variable declaration associating an identifier with a biological type and expression.</li>
            <li><code>AssignNode</code>: Reassignment maintaining strict type stability.</li>
            <li><code>FunctionCallNode</code>: Biological function invocation (<code>transcribe</code>, <code>translate</code>, etc.).</li>
            <li><code>PlotStmtNode</code>: First-class genomic visualization command.</li>
          </ul>
        </div>

        <div class="card-rose">
          <b>3. Scoped Symbol Table (<code>genomedsl/symbol_table.py</code>)</b><br>
          Maintains an environment registry of declared variables, biological types, and source coordinates.
          Prevents undeclared identifier access, accidental redeclarations, and scope leakage.
        </div>

        <div class="card-honey">
          <b>4. Semantic Analyzer &amp; Central Dogma Rules (<code>genomedsl/semantic_analyzer.py</code>)</b><br>
          Enforces biological reality before code is allowed to execute:
          <ul>
            <li><b>Alphabet Validation:</b> Verifies that no rogue chemical bases exist (e.g. catches Uracil in DNA or non-amino acid codes in Protein).</li>
            <li><b>Central Dogma Enforcement:</b> Validates that <code>transcribe()</code> receives <code>DNA</code> and yields <code>RNA</code>; validates that <code>translate()</code> receives <code>RNA</code> and yields <code>Protein</code>. Translating DNA directly or transcribing RNA throws a compile-time <code>BiologicalTypeError</code>.</li>
          </ul>
        </div>

        <div class="card-sage">
          <b>5. AST Optimizer (<code>genomedsl/optimizer.py</code>)</b><br>
          Performs algebraic domain-specific reductions on the Abstract Syntax Tree prior to runtime:
          <ul>
            <li><b>Constant Expression Folding:</b> Evaluates pure functions on literal strings at compile-time (e.g. <code>length("ATGC") &rarr; 4</code>).</li>
            <li><b>Reversible Operation Elimination:</b> Recognizes involution symmetries: <code>reverse_complement(reverse_complement(x)) &rarr; x</code> and <code>reverse(reverse(x)) &rarr; x</code>.</li>
          </ul>
        </div>

        <div class="card-oxford">
          <b>6. Biopython Execution Backend (<code>genomedsl/backend.py</code>)</b><br>
          Interprets the verified AST using <code>Bio.Seq</code> and NCBI Standard Translation Table 1.
          Implements Task 2 <code>compare()</code> (percentage identity) and Task 3 <code>find_motif()</code> (1-based overlapping search).
        </div>
        """, unsafe_allow_html=True)

        # Show full architecture diagram from evidence if available
        arch_img = os.path.join(os.path.dirname(__file__), "evidence", "architecture_diagram.png")
        if os.path.exists(arch_img):
            st.markdown(_section("FORMAL COMPILER SPECIFICATION DIAGRAM"), unsafe_allow_html=True)
            st.image(arch_img, use_container_width=True, caption="Figure 2: Complete GenomeDSL Multi-Pass Compiler Architectural Diagram")


    # ── TAB 2: PLATFORM PACKAGES DEEP-DIVE ──
    with tab_packages:
        st.markdown("### The Three Core Platform Packages")
        st.markdown("GenomeDSL stands on the shoulders of three world-class open-source libraries. Here is how each is leveraged:")

        st.markdown("""
        #### 1. `lark-parser` (Lexical &amp; Syntactic Analysis)
        * **Role in GenomeDSL:** Parses the domain-specific language grammar from raw string into a structured AST.
        * **Why Lark?**
          1. **Earley Algorithm:** Lark supports Earley parsing, meaning it can parse any context-free grammar without ambiguity traps or shift/reduce conflicts.
          2. **Transformer Pattern:** Provides an elegant tree visitor interface (`lark.Transformer`) that enables declarative transformation from parse trees into typed dataclasses.
        * **Hook in Codebase:**
        ```python
        # genomedsl/parser.py
        from lark import Lark, Transformer
        from genomedsl.grammar import GENOMEDSL_GRAMMAR

        _parser = Lark(GENOMEDSL_GRAMMAR, start="program", parser="earley")
        cst = _parser.parse(source_code)
        ast = ASTBuilder().transform(cst)
        ```
        <br>

        #### 2. `biopython` (Molecular Sequence Computation)
        * **Role in GenomeDSL:** Powers biological transformations (`transcribe`, `translate`, `reverse_complement`).
        * **Why Biopython?**
          1. **Biological Precision:** Handles the IUPAC genetic code, degenerate codons, and NCBI Translation Table 1.
          2. **Verified Implementations:** Millions of bioinformaticians rely on Biopython's `Seq` object and `pairwise2` algorithms for research-grade correctness.
        * **Hook in Codebase:**
        ```python
        # genomedsl/backend.py
        from Bio.Seq import Seq
        from Bio.SeqUtils import gc_fraction

        # Transcription: DNA -> RNA
        rna_seq = str(Seq(dna_seq).transcribe())

        # Translation: RNA -> Protein
        protein_seq = str(Seq(rna_seq).translate(to_stop=False))

        # Antiparallel Reverse Complement
        rc_seq = str(Seq(seq_str).reverse_complement())
        ```
        <br>

        #### 3. `matplotlib` (Publication-Grade Visualizations)
        * **Role in GenomeDSL:** Generates the dual-panel sliding window GC-content profile and nucleotide distribution chart.
        * **Why Matplotlib with Agg Backend?**
          1. **Headless Execution:** By invoking `matplotlib.use("Agg")`, charts are rendered entirely in-memory without needing a display server or graphical window (essential for web servers and Streamlit).
          2. **Subplot Coordination:** `GridSpec` coordinates a dual-axis layout pairing continuous rolling averages with discrete bar distributions.
        * **Hook in Codebase:**
        ```python
        # genomedsl/visualizer.py
        import matplotlib
        matplotlib.use("Agg") # Non-interactive headless backend
        import matplotlib.pyplot as plt

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), gridspec_kw={"height_ratios": [2.5, 1.2]})
        ax1.plot(positions, gc_vals, color="#2b5c8f")
        ax2.bar(labels, freqs, color=bar_colors)
        plt.savefig(out_path, dpi=150)
        ```
        """, unsafe_allow_html=True)


    # ── TAB 3: COMPLETE DSL LANGUAGE RULES ──
    with tab_rules:
        st.markdown("### Formal Language Rules &amp; Specification")

        # Embed Central Dogma and Base Pairing SVGs
        col_svg1, col_svg2 = st.columns(2)
        dogma_svg = os.path.join(os.path.dirname(__file__), "assets", "central_dogma_diagram.svg")
        pairing_svg = os.path.join(os.path.dirname(__file__), "assets", "dna_base_pairing.svg")

        with col_svg1:
            if os.path.exists(dogma_svg):
                with open(dogma_svg, "r", encoding="utf-8") as f:
                    st.markdown(f.read(), unsafe_allow_html=True)
        with col_svg2:
            if os.path.exists(pairing_svg):
                with open(pairing_svg, "r", encoding="utf-8") as f:
                    st.markdown(f.read(), unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown(r"""
        #### 1. Core Biological Types & Alphabets
        | Type | Valid Chemical Alphabet | Description | Invariants Enforced |
        |:---|:---|:---|:---|
        | `DNA` | `A, T, G, C` | Double-stranded DNA sequence | Rejects Uracil (`U`). Case-insensitive literal normalization. |
        | `RNA` | `A, U, G, C` | Single-stranded messenger RNA | Rejects Thymine (`T`). Case-insensitive literal normalization. |
        | `Protein` | 20 IUPAC amino acids + `*` | Functional polypeptide chain | Rejects letters `B, J, O, U, X, Z`. Permits stop codon symbol `*`. |
        | `RESULT` | Integers, Floats, Lists | Computational metrics & coordinates | Holds GC percentages, sequence lengths, and motif coordinate lists. |

        #### 2. Built-in Biological Functions Specification
        | Function | Input Type | Output Type | Description & Behavior | Complexity |
        |:---|:---:|:---:|:---|:---:|
        | `transcribe(seq)` | `DNA` | `RNA` | Converts DNA to mRNA by replacing Thymine (`T`) with Uracil (`U`). | $\mathcal{O}(n)$ |
        | `translate(seq)` | `RNA` | `Protein` | Translates mRNA codons into amino acid residues via NCBI Table 1. | $\mathcal{O}(n)$ |
        | `reverse_complement(seq)` | `DNA` or `RNA` | same | Generates antiparallel complementary strand ($5' \to 3'$). | $\mathcal{O}(n)$ |
        | `reverse(seq)` | any | same | Reverses the string order ($3' \to 5'$). | $\mathcal{O}(n)$ |
        | `gc_content(seq)` | `DNA` or `RNA` | `RESULT` (float) | Computes percentage of Guanine and Cytosine bases ($0.0 - 100.0\%$). | $\mathcal{O}(n)$ |
        | `length(seq)` | any | `RESULT` (int) | Returns the total count of nucleotides or amino acid residues. | $\mathcal{O}(1)$ |
        | `compare(seq1, seq2)` | matching types | `RESULT` (float) | Calculates percentage identity via residue matching. | $\mathcal{O}(n)$ |
        | `find_motif(seq, motif)` | any, string | `RESULT` (list) | Returns **1-based biological coordinates** of motif hits (supports overlaps). | $\mathcal{O}(n \cdot m)$ |

        #### 3. Output Statements
        ```gdsl
        PRINT "Label:", variable_name
        PLOT  gc_content(dna_gene)   # Generates sliding-window GC profile chart
        ```

        #### 4. Compiler Error Hierarchy
        * `AlphabetError`: Raised at compile-time when a sequence literal violates its chemical alphabet (e.g. `DNA x = "AUGC"`).
        * `BiologicalTypeError`: Raised when an operation violates the Central Dogma (e.g. calling `transcribe(rna_var)` or `translate(dna_var)`).
        * `SemanticError`: Raised for undeclared variables, duplicate declarations in the same scope, or type mismatches.
        * `SyntaxError`: Raised by Lark for malformed grammar tokens or missing brackets.
        """)


    # ── TAB 4: 12 INTERACTIVE PRACTICE CHALLENGES ──
    with tab_challenges:
        st.markdown("### 12 Guided Hands-on Practice Challenges")
        st.markdown("Click **'🚀 Load into Studio & Solve'** on any challenge to open it in the Studio IDE with one click!")

        CHALLENGES = [
            {
                "id": 1,
                "title": "Challenge 1: First DNA Sequence & Length Measurement",
                "level": "Beginner",
                "desc": "Declare a double-stranded DNA sequence for a short bacteriophage promoter and calculate its length in base pairs.",
                "starter": '# Challenge 1: Declare DNA and measure length\nDNA phage_seq = "ATGCGATCGATCGATC"\nRESULT seq_length = length(phage_seq)\n\nPRINT "Declared DNA:    ", phage_seq\nPRINT "Length (bp):     ", seq_length\n',
                "hint": "Use the DNA type keyword and the length() built-in function."
            },
            {
                "id": 2,
                "title": "Challenge 2: Base Composition & GC-Content Percentage",
                "level": "Beginner",
                "desc": "Thermal stability of double-stranded DNA depends on GC-content. Calculate the GC percentage for this sequence.",
                "starter": '# Challenge 2: GC-Content calculation\nDNA probe = "GCGCATATGCGCGC"\nRESULT gc = gc_content(probe)\n\nPRINT "Oligo Probe:     ", probe\nPRINT "GC Density (%):  ", gc\n',
                "hint": "gc_content() returns a float value between 0.0 and 100.0."
            },
            {
                "id": 3,
                "title": "Challenge 3: Gene Transcription (DNA to mRNA)",
                "level": "Beginner",
                "desc": "Simulate the action of RNA Polymerase by transcribing a protein-coding gene into messenger RNA.",
                "starter": '# Challenge 3: Transcription\nDNA coding_gene = "ATGCGTACCGTA"\nRNA mrna = transcribe(coding_gene)\n\nPRINT "DNA Gene:        ", coding_gene\nPRINT "Transcribed mRNA:", mrna\n',
                "hint": "transcribe() takes a DNA variable and returns an RNA transcript."
            },
            {
                "id": 4,
                "title": "Challenge 4: Ribosomal Translation (mRNA to Polypeptide)",
                "level": "Beginner",
                "desc": "Translate an mRNA transcript into its functional amino acid sequence using the universal genetic code.",
                "starter": '# Challenge 4: Translation\nRNA mrna_sample = "AUGCGUACCGUA"\nProtein peptide = translate(mrna_sample)\n\nPRINT "mRNA Transcript: ", mrna_sample\nPRINT "Translated Chain:", peptide\n',
                "hint": "translate() takes an RNA variable and returns a Protein sequence."
            },
            {
                "id": 5,
                "title": "Challenge 5: Generating the Antiparallel Reverse Complement",
                "level": "Intermediate",
                "desc": "PCR primers bind to the antiparallel reverse complement strand. Generate the reverse complement of this target sequence.",
                "starter": '# Challenge 5: Reverse Complement\nDNA target = "ATGCGATCGTA"\nDNA primer = reverse_complement(target)\n\nPRINT "Target Strand:   ", target\nPRINT "Binding Primer:  ", primer\n',
                "hint": "reverse_complement(DNA) complements bases (A<->T, G<->C) and reverses string direction."
            },
            {
                "id": 6,
                "title": "Challenge 6: Homologous Sequence Comparison (`compare`)",
                "level": "Intermediate",
                "desc": "Compare a reference wildtype sequence with a mutated clinical variant to determine the percentage identity match.",
                "starter": '# Challenge 6: Sequence Comparison\nDNA wildtype = "ATGCGTAC"\nDNA mutant   = "ATGGGTAC"\nRESULT match_pct = compare(wildtype, mutant)\n\nPRINT "Wildtype:        ", wildtype\nPRINT "Mutant:          ", mutant\nPRINT "Identity (%):    ", match_pct\n',
                "hint": "compare(seq1, seq2) calculates matching residues divided by maximum sequence length."
            },
            {
                "id": 7,
                "title": "Challenge 7: Core Promoter TATA-Box Motif Scan (`find_motif`)",
                "level": "Intermediate",
                "desc": "Locate all 1-based start coordinates of the core eukaryotic promoter consensus motif 'TATAAA'.",
                "starter": '# Challenge 7: TATA-Box Motif Search\nDNA promoter_region = "GGCCCGTATAAAGGCTATAAACCCGGG"\nRESULT hit_positions = find_motif(promoter_region, "TATAAA")\n\nPRINT "Promoter Region: ", promoter_region\nPRINT "TATA-box Hits:   ", hit_positions\n',
                "hint": "find_motif() returns a list of 1-based biological coordinates."
            },
            {
                "id": 8,
                "title": "Challenge 8: Compiler Algebraic Optimization Verification",
                "level": "Intermediate",
                "desc": "Verify that the AST optimizer eliminates redundant reversible operations: reverse_complement(reverse_complement(x)) -> x.",
                "starter": '# Challenge 8: Optimization check\nDNA test_strand = "ATGCGTAC"\nDNA unoptimized = reverse_complement(reverse_complement(test_strand))\n\nPRINT "Original Strand: ", test_strand\nPRINT "Optimized Result:", unoptimized\n',
                "hint": "Enable the AST Optimizer toggle in the Studio and inspect the reduction count!"
            },
            {
                "id": 9,
                "title": "Challenge 9: Sickle Cell Mutation Analysis (HbA vs HbS)",
                "level": "Advanced",
                "desc": "Detect the single nucleotide polymorphism (SNP) in human β-globin codon 6 that causes sickle cell anemia (GAG -> GTG, Glu -> Val).",
                "starter": '# Challenge 9: Sickle Cell Mutation (HbA vs HbS)\nDNA hba_normal = "GTGCACCTGACTCCTGAGGAG"\nDNA hbs_mutant = "GTGCACCTGACTCCTGTGGAG"\n\nRNA rna_normal = transcribe(hba_normal)\nRNA rna_mutant = transcribe(hbs_mutant)\n\nProtein prot_normal = translate(rna_normal)\nProtein prot_mutant = translate(rna_mutant)\n\nRESULT identity = compare(hba_normal, hbs_mutant)\n\nPRINT "Normal HbA Protein: ", prot_normal\nPRINT "Sickle HbS Protein: ", prot_mutant\nPRINT "Sequence Identity:  ", identity\n',
                "hint": "Notice how the 6th amino acid residue changes from Glutamate (E) to Valine (V)."
            },
            {
                "id": 10,
                "title": "Challenge 10: CRISPR-Cas9 Protospacer Adjacent Motif (PAM) Finder",
                "level": "Advanced",
                "desc": "Cas9 endonuclease requires an 'NGG' PAM motif adjacent to target protospacer sites. Find all candidate 'CGG' and 'TGG' sites.",
                "starter": '# Challenge 10: CRISPR-Cas9 PAM Finder\nDNA target_locus = "ATGCGGTACTGGCCATCGG"\nRESULT pam_cgg = find_motif(target_locus, "CGG")\nRESULT pam_tgg = find_motif(target_locus, "TGG")\n\nPRINT "Target Locus:    ", target_locus\nPRINT "PAM \'CGG\' Sites: ", pam_cgg\nPRINT "PAM \'TGG\' Sites: ", pam_tgg\n',
                "hint": "Look for 1-based start coordinates for both PAM variations."
            },
            {
                "id": 11,
                "title": "Challenge 11: Poly-A Tail Identification",
                "level": "Advanced",
                "desc": "Mature eukaryotic mRNAs feature a 3' polyadenylated tail. Locate the poly-A signal motif 'AAUAAA'.",
                "starter": '# Challenge 11: Poly-A Signal Identification\nRNA mature_transcript = "AUGCCGUAACGUAAUAAAGCAAAAAAAAAAAAAAAAAAAA"\nRESULT poly_a_signal = find_motif(mature_transcript, "AAUAAA")\nRESULT total_len = length(mature_transcript)\n\nPRINT "mRNA Transcript: ", mature_transcript\nPRINT "Signal Site:     ", poly_a_signal\nPRINT "Total Length:    ", total_len\n',
                "hint": "find_motif works equally well on RNA and Protein sequences."
            },
            {
                "id": 12,
                "title": "Challenge 12: High-Resolution GC Profile Plotting",
                "level": "Advanced",
                "desc": "Generate a publication-grade dual-panel sliding window GC curve and nucleotide composition chart using the PLOT statement.",
                "starter": '# Challenge 12: Genomic Plotting\nDNA viral_genome = "ATGCGATCGATCGATCGCGCGCATATATCGATCGATCGATCGATCGCGCTATATAGC"\nRESULT gc = gc_content(viral_genome)\n\nPRINT "Viral Segment:   ", viral_genome\nPRINT "Overall GC (%):  ", gc\n\nPLOT gc_content(viral_genome)\n',
                "hint": "The PLOT statement automatically invokes the Matplotlib Agg visualizer!"
            },
        ]

        # Render challenge cards
        for ch in CHALLENGES:
            badge_color = "#4D6A56" if ch["level"] == "Beginner" else ("#567AA6" if ch["level"] == "Intermediate" else "#A65B6A")
            st.markdown(f"""
            <div class="try-box">
              <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="try-title">🏆 {ch['title']}</span>
                <span style="background:{badge_color}; color:#FAF8F5; font-size:0.74rem; font-weight:700; padding:2px 8px; border-radius:4px;">
                  {ch['level']}
                </span>
              </div>
              <div style="font-size:0.86rem; color:#CBD5E1; margin:0.4rem 0 0.6rem;">{ch['desc']}</div>
              <div style="font-size:0.80rem; color:#84A98C; font-style:italic; margin-bottom:0.7rem;">💡 <b>Hint:</b> {ch['hint']}</div>
            </div>
            """, unsafe_allow_html=True)

            col_btn, _ = st.columns([1.5, 3.5])
            with col_btn:
                if st.button(f"🚀 Load Challenge {ch['id']} into Studio & Solve", key=f"btn_ch_{ch['id']}", type="primary"):
                    st.session_state["active_code"] = ch["starter"]
                    st.session_state["app_nav"] = "🔬 Studio & IDE"
                    st.rerun()


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4 — MOLECULAR SANDBOX & CODON TOOLS
# ══════════════════════════════════════════════════════════════════════════════
elif nav == "🧪 Molecular Sandbox & Codon Tools":
    st.markdown("""
    <div class="english-hero">
      <div style="font-size:0.78rem; font-weight:700; letter-spacing:1px; color:#84A98C; text-transform:uppercase;">
        Interactive Biochemical Sandbox &bull; Genetic Code Inspector
      </div>
      <div style="font-family:'Cinzel', serif; font-size:1.85rem; font-weight:700; color:#F7F5F0; margin:0.3rem 0;">
        Molecular Sandbox &amp; Codon Reference
      </div>
      <div style="font-size:0.92rem; color:#CBD5E1; max-width:880px; line-height:1.6;">
        Inspect arbitrary sequences in real-time for chemical classification, molecular weight, melting temperature ($T_m$),
        and explore the universal genetic codon wheel.
      </div>
    </div>
    """, unsafe_allow_html=True)

    tab_chem_sandbox, tab_codon_wheel = st.tabs([
        "🧪 Sequence Chemistry & Biophysical Sandbox",
        "🧬 Interactive Codon & Amino Acid Wheel",
    ])

    with tab_chem_sandbox:
        st.markdown("### Real-Time Biophysical Sequence Inspector")
        raw_input = st.text_area(
            "Paste Raw Sequence (DNA, RNA, or Protein):",
            value="ATGCGTACCGTA",
            height=100,
            placeholder="e.g. ATGCGTACCGTA or AUGCCGUAC or GIVEQCCTSICSLYQLENYCN",
        )

        clean_seq = raw_input.strip().upper().replace(" ", "").replace("\n", "").replace("\r", "")

        if clean_seq:
            length_val = len(clean_seq)
            count_a = clean_seq.count("A")
            count_t = clean_seq.count("T")
            count_g = clean_seq.count("G")
            count_c = clean_seq.count("C")
            count_u = clean_seq.count("U")

            is_dna = all(ch in "ATGC" for ch in clean_seq) and ("T" in clean_seq or "U" not in clean_seq)
            is_rna = all(ch in "AUGC" for ch in clean_seq) and ("U" in clean_seq or "T" not in clean_seq)
            is_protein = all(ch in "ACDEFGHIKLMNPQRSTVWY*" for ch in clean_seq)

            if is_dna and not is_rna:
                detected_type = "DNA"
                badge_class = "card-sage"
                mw = round((count_a * 313.21) + (count_t * 304.2) + (count_c * 289.18) + (count_g * 329.21) - 61.96, 2)
                gc_pct = round(((count_g + count_c) / length_val) * 100.0, 2) if length_val > 0 else 0.0
                tm_est = round(2 * (count_a + count_t) + 4 * (count_g + count_c), 1) if length_val < 14 else round(64.9 + 41 * (count_g + count_c - 16.4) / length_val, 1)
            elif is_rna and not is_dna:
                detected_type = "RNA"
                badge_class = "card-oxford"
                mw = round((count_a * 329.21) + (count_u * 306.17) + (count_c * 305.18) + (count_g * 345.21) + 159.0, 2)
                gc_pct = round(((count_g + count_c) / length_val) * 100.0, 2) if length_val > 0 else 0.0
                tm_est = round(2 * (count_a + count_u) + 4 * (count_g + count_c), 1)
            elif is_protein:
                detected_type = "Protein"
                badge_class = "card-rose"
                mw = round(length_val * 110.0, 2)
                gc_pct = 0.0
                tm_est = 0.0
            else:
                detected_type = "Unrecognized / Contaminated"
                badge_class = "card-rose"
                mw = 0.0
                gc_pct = 0.0
                tm_est = 0.0

            st.markdown(f"""
            <div class="{badge_class}">
              <b>Detected Biological Entity:</b> <span style="font-weight:700; font-size:1.05rem;">{detected_type}</span> &bull;
              Length: <b>{length_val} residues</b>
              {' &bull; Estimated Molecular Weight: <b>' + str(mw) + ' Da</b>' if mw > 0 else ''}
              {' &bull; Estimated Melting Temperature (Tm): <b>' + str(tm_est) + ' &deg;C</b>' if tm_est > 0 else ''}
            </div>
            """, unsafe_allow_html=True)

            col_m1, col_m2, col_m3, col_m4 = st.columns(4)
            col_m1.metric("Sequence Length", f"{length_val} bp" if detected_type in ("DNA", "RNA") else f"{length_val} aa")
            col_m2.metric("GC-Content", f"{gc_pct}%" if detected_type in ("DNA", "RNA") else "N/A (Protein)")
            col_m3.metric("Estimated Mass", f"{mw:,.1f} Da" if mw > 0 else "N/A")
            col_m4.metric("Melting Temp (Tm)", f"{tm_est} °C" if tm_est > 0 else "N/A")

            # Nucleotide distribution
            if detected_type in ("DNA", "RNA"):
                st.markdown(_section("NUCLEOTIDE COMPOSITION BREAKDOWN"), unsafe_allow_html=True)
                b1, b2, b3, b4 = st.columns(4)
                b1.metric("Adenine (A)", f"{count_a} ({round(count_a/length_val*100, 1)}%)")
                b2.metric("Thymine/Uracil", f"{count_t if is_dna else count_u} ({round((count_t if is_dna else count_u)/length_val*100, 1)}%)")
                b3.metric("Guanine (G)", f"{count_g} ({round(count_g/length_val*100, 1)}%)")
                b4.metric("Cytosine (C)", f"{count_c} ({round(count_c/length_val*100, 1)}%)")

            if detected_type in ("DNA", "RNA", "Protein"):
                var_name = "my_dna" if detected_type == "DNA" else ("my_rna" if detected_type == "RNA" else "my_protein")
                auto_code = f'{detected_type} {var_name} = "{clean_seq}"\n'
                if detected_type == "DNA":
                    auto_code += f'RNA transcript = transcribe({var_name})\nRESULT gc = gc_content({var_name})\nPRINT "DNA Sequence: ", {var_name}\nPRINT "Transcribed:  ", transcript\nPRINT "GC Content:   ", gc\nPLOT gc_content({var_name})'
                elif detected_type == "RNA":
                    auto_code += f'Protein peptide = translate({var_name})\nRESULT gc = gc_content({var_name})\nPRINT "RNA Transcript: ", {var_name}\nPRINT "Translated:     ", peptide'
                else:
                    auto_code += f'RESULT aa_len = length({var_name})\nPRINT "Protein Sequence: ", {var_name}\nPRINT "Amino Acid Count: ", aa_len'

                if st.button("📥 Load Analyzed Sequence into Studio IDE", key="btn_load_sandbox", type="primary"):
                    st.session_state["active_code"] = auto_code
                    st.session_state["app_nav"] = "🔬 Studio & IDE"
                    st.rerun()

    with tab_codon_wheel:
        st.markdown("### Universal Codon &amp; Amino Acid Lookup Wheel")
        st.markdown("Select base triplets ($5' \\to 3'$) to reveal the translated amino acid, biochemical class, and corresponding GenomeDSL translation code:")

        c1, c2, c3 = st.columns(3)
        with c1:
            base1 = st.selectbox("1st Base (5' end):", ["A", "U", "G", "C"], index=0)
        with c2:
            base2 = st.selectbox("2nd Base (middle):", ["A", "U", "G", "C"], index=1)
        with c3:
            base3 = st.selectbox("3rd Base (3' end):", ["A", "U", "G", "C"], index=2)

        selected_triplet = f"{base1}{base2}{base3}".upper()
        info = CODON_MAP.get(selected_triplet, ("Unknown", "Unk", "?", "Custom"))
        full_name, abbrev, single_letter, bio_class = info

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown(_section(f"CODON TRANSLATION: {selected_triplet}"), unsafe_allow_html=True)

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Amino Acid Name", full_name)
        m2.metric("Single-Letter Code", single_letter)
        m3.metric("3-Letter Abbr.", abbrev)
        m4.metric("Biochemical Class", bio_class)

        st.markdown(f"""
        <div class="card-rose" style="margin-top:1.2rem;">
          <b>GenomeDSL Translation Behavior:</b><br>
          Calling <code>translate("{selected_triplet}")</code> directly produces the protein residue:
          <span style="font-size:1.1rem; font-weight:700; color:#FCA5A5; margin-left:6px;">'{single_letter}' ({full_name})</span>
        </div>
        """, unsafe_allow_html=True)

        snippet = f'RNA codon = "{selected_triplet}"\nProtein residue = translate(codon)\nPRINT "Codon {selected_triplet} translated to: ", residue'
        st.code(snippet, language="python")

        if st.button("🚀 Load this Codon Test into Studio", key="btn_load_codon", type="primary"):
            st.session_state["active_code"] = snippet
            st.session_state["app_nav"] = "🔬 Studio & IDE"
            st.rerun()
