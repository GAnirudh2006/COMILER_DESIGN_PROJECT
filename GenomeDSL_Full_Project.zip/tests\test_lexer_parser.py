"""
Tests for GenomeDSL Lexer, Parser, and AST Builder.
"""

import pytest
from genomedsl.parser import parse_code
from genomedsl.ast_nodes import Program, VarDecl, AssignStmt, PrintStmt, PlotStmt, FunctionCall, Literal, Identifier
from genomedsl.errors import LexicalError, SyntaxError


def test_parse_simple_declarations():
    code = """
    DNA gene = "ATGCGTAC"
    RNA rna1 = transcribe(gene)
    Protein protein1 = translate(rna1)
    RESULT gc = gc_content(gene)
    """
    ast = parse_code(code)
    assert isinstance(ast, Program)
    assert len(ast.statements) == 4

    stmt0 = ast.statements[0]
    assert isinstance(stmt0, VarDecl)
    assert stmt0.type_name == "DNA"
    assert stmt0.var_name == "gene"
    assert isinstance(stmt0.expr, Literal)
    assert stmt0.expr.value == "ATGCGTAC"

    stmt1 = ast.statements[1]
    assert isinstance(stmt1, VarDecl)
    assert stmt1.type_name == "RNA"
    assert stmt1.var_name == "rna1"
    assert isinstance(stmt1.expr, FunctionCall)
    assert stmt1.expr.name == "transcribe"
    assert len(stmt1.expr.args) == 1
    assert isinstance(stmt1.expr.args[0], Identifier)
    assert stmt1.expr.args[0].name == "gene"


def test_parse_multi_arg_function_and_assignment():
    code = """
    DNA seq = "ATGC"
    RESULT motif = find_motif(seq, "ATG")
    seq = reverse_complement(seq)
    """
    ast = parse_code(code)
    assert len(ast.statements) == 3

    motif_stmt = ast.statements[1]
    assert isinstance(motif_stmt, VarDecl)
    assert motif_stmt.type_name == "RESULT"
    call = motif_stmt.expr
    assert isinstance(call, FunctionCall)
    assert call.name == "find_motif"
    assert len(call.args) == 2

    assign_stmt = ast.statements[2]
    assert isinstance(assign_stmt, AssignStmt)
    assert assign_stmt.var_name == "seq"
    assert assign_stmt.expr.name == "reverse_complement"


def test_parse_print_and_plot():
    code = """
    DNA gene = "ATGC"
    PRINT gene
    PRINT "GC:", gc_content(gene)
    PLOT gc_content(gene)
    """
    ast = parse_code(code)
    assert len(ast.statements) == 4
    assert isinstance(ast.statements[1], PrintStmt)
    assert len(ast.statements[1].expressions) == 1

    assert isinstance(ast.statements[2], PrintStmt)
    assert len(ast.statements[2].expressions) == 2

    assert isinstance(ast.statements[3], PlotStmt)
    assert ast.statements[3].call.name == "gc_content"


def test_comments_and_semicolons():
    code = """
    # This is a comment
    DNA seq = "ATGC"; // C-style comment
    RESULT gc = gc_content(seq);
    """
    ast = parse_code(code)
    assert len(ast.statements) == 2


def test_syntax_error_missing_expression():
    code = "DNA gene ="
    with pytest.raises(SyntaxError):
        parse_code(code)


def test_lexical_error_invalid_char():
    code = "DNA gene = @invalid"
    with pytest.raises(LexicalError):
        parse_code(code)
