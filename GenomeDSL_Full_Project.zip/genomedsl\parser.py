"""
Lexical analysis and syntactic parsing for GenomeDSL.
Converts source code into a Lark parse tree, then transforms it into an AST.
"""

from typing import List, Optional
from lark import Lark, Transformer, Token, Tree
from lark.exceptions import (
    UnexpectedCharacters,
    UnexpectedToken,
    LarkError,
)

from genomedsl.grammar import GENOMEDSL_GRAMMAR
from genomedsl.ast_nodes import (
    Program,
    Statement,
    VarDecl,
    AssignStmt,
    PrintStmt,
    PlotStmt,
    FunctionCall,
    Literal,
    Identifier,
    Expr,
)
from genomedsl.errors import LexicalError, SyntaxError


class ASTBuilder(Transformer):
    """Transforms Lark parse tree nodes into GenomeDSL AST dataclass instances."""

    def program(self, items: List[Optional[Statement]]) -> Program:
        # Filter out empty newlines or None statements
        stmts = [stmt for stmt in items if stmt is not None]
        line = stmts[0].line if stmts else 1
        col = stmts[0].column if stmts else 1
        return Program(line=line, column=col, statements=stmts)

    def var_decl(self, items) -> VarDecl:
        type_token, name_token, expr = items
        return VarDecl(
            line=getattr(type_token, "line", None),
            column=getattr(type_token, "column", None),
            type_name=str(type_token),
            var_name=str(name_token),
            expr=expr,
        )

    def assign_stmt(self, items) -> AssignStmt:
        name_token, expr = items
        return AssignStmt(
            line=getattr(name_token, "line", None),
            column=getattr(name_token, "column", None),
            var_name=str(name_token),
            expr=expr,
        )

    def print_stmt(self, items) -> PrintStmt:
        exprs = items
        line = exprs[0].line if exprs else None
        col = exprs[0].column if exprs else None
        return PrintStmt(
            line=line,
            column=col,
            expressions=exprs,
        )

    def plot_stmt(self, items) -> PlotStmt:
        call = items[0]
        return PlotStmt(
            line=call.line,
            column=call.column,
            call=call,
        )

    def function_call(self, items) -> FunctionCall:
        name_token = items[0]
        args = items[1] if len(items) > 1 and items[1] is not None else []
        return FunctionCall(
            line=getattr(name_token, "line", None),
            column=getattr(name_token, "column", None),
            name=str(name_token),
            args=args,
        )

    def arg_list(self, items) -> List[Expr]:
        return [item for item in items if item is not None]

    def var_ref(self, items) -> Identifier:
        token = items[0]
        return Identifier(
            line=getattr(token, "line", None),
            column=getattr(token, "column", None),
            name=str(token),
        )

    def string_lit(self, items) -> Literal:
        token = items[0]
        # Remove surrounding quotes and unescape
        val = str(token)[1:-1]
        return Literal(
            line=getattr(token, "line", None),
            column=getattr(token, "column", None),
            value=val,
            lit_type="STRING",
        )

    def number_lit(self, items) -> Literal:
        token = items[0]
        text = str(token)
        val = float(text) if ("." in text or "e" in text.lower()) else int(text)
        return Literal(
            line=getattr(token, "line", None),
            column=getattr(token, "column", None),
            value=val,
            lit_type="FLOAT" if isinstance(val, float) else "INT",
        )


class GenomeDSLParser:
    """Wrapper around Lark parser with customized error reporting."""

    def __init__(self):
        self._lark = Lark(
            GENOMEDSL_GRAMMAR,
            parser="earley",
            propagate_positions=True,
        )
        self._transformer = ASTBuilder()

    def parse(self, source_code: str) -> Program:
        """Parses GenomeDSL source code and returns the root Program AST."""
        try:
            tree = self._lark.parse(source_code)
            ast = self._transformer.transform(tree)
            return ast
        except UnexpectedCharacters as uc:
            line_content = source_code.splitlines()[uc.line - 1] if uc.line <= len(source_code.splitlines()) else ""
            raise LexicalError(
                message=f"Invalid character '{uc.char}' encountered",
                line=uc.line,
                column=uc.column,
                source_line=line_content,
            ) from uc
        except UnexpectedToken as ut:
            line_content = source_code.splitlines()[ut.line - 1] if ut.line <= len(source_code.splitlines()) else ""
            expected = ", ".join(ut.expected) if ut.expected else "unknown token"
            raise SyntaxError(
                message=f"Unexpected token '{ut.token}' (expected: {expected})",
                line=ut.line,
                column=ut.column,
                source_line=line_content,
            ) from ut
        except LarkError as le:
            raise SyntaxError(message=f"Parse error: {str(le)}") from le


def parse_code(code: str) -> Program:
    """Convenience helper to parse GenomeDSL source code."""
    parser = GenomeDSLParser()
    return parser.parse(code)
