"""
Custom exception hierarchy for GenomeDSL compiler phases.
Includes source code location reporting (line, column) for professional error diagnostics.
"""

from typing import Optional


class GenomeDSLError(Exception):
    """Base class for all GenomeDSL errors."""

    def __init__(
        self,
        message: str,
        line: Optional[int] = None,
        column: Optional[int] = None,
        source_line: Optional[str] = None,
    ):
        self.message = message
        self.line = line
        self.column = column
        self.source_line = source_line
        super().__init__(self.format_error())

    def format_error(self) -> str:
        loc = []
        if self.line is not None:
            loc.append(f"line {self.line}")
        if self.column is not None:
            loc.append(f"column {self.column}")
        loc_str = f" [{', '.join(loc)}]" if loc else ""

        banner = f"[{self.__class__.__name__}]{loc_str}: {self.message}"
        if self.source_line and self.column is not None:
            pointer = " " * (self.column - 1) + "^"
            return f"{banner}\n    {self.source_line}\n    {pointer}"
        return banner


class LexicalError(GenomeDSLError):
    """Raised during tokenization when an unrecognized token is encountered."""
    pass


class SyntaxError(GenomeDSLError):
    """Raised during parsing when syntax rules are violated."""
    pass


class SemanticError(GenomeDSLError):
    """Raised during semantic analysis (e.g. undeclared identifier, duplicate declaration)."""
    pass


class BiologicalTypeError(SemanticError):
    """Raised when an operation is applied to an incompatible biological sequence type."""
    pass


class AlphabetError(SemanticError):
    """Raised when sequence characters violate the biological alphabet for DNA, RNA, or Protein."""
    pass


class GenomeDSLRuntimeError(GenomeDSLError):
    """Raised during backend program execution."""
    pass
