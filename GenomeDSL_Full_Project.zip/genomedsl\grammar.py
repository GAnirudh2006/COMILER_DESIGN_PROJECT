"""
Lark EBNF Grammar definition for GenomeDSL.
Supports declarations, assignments, function calls, literals, PRINT and PLOT statements.
"""

GENOMEDSL_GRAMMAR = r"""
    ?start: program

    program: (statement | _NL)*

    ?statement: var_decl
              | assign_stmt
              | print_stmt
              | plot_stmt

    var_decl: TYPE_NAME CNAME "=" expr
    assign_stmt: CNAME "=" expr
    print_stmt: ("PRINT" | "print") expr ("," expr)*
    plot_stmt: ("PLOT" | "plot") function_call

    ?expr: function_call
         | literal
         | var_ref

    function_call: CNAME "(" [arg_list] ")"
    arg_list: expr ("," expr)*

    var_ref: CNAME

    ?literal: string_lit
            | number_lit

    string_lit: ESCAPED_STRING
    number_lit: SIGNED_NUMBER

    TYPE_NAME: "DNA" | "RNA" | "Protein" | "RESULT"

    %import common.CNAME
    %import common.ESCAPED_STRING
    %import common.SIGNED_NUMBER
    %import common.WS_INLINE
    %import common.NEWLINE -> _NL

    COMMENT: /#[^\n]*/ | /\/\/[^\n]*/

    %ignore WS_INLINE
    %ignore COMMENT
    %ignore ";"
"""
