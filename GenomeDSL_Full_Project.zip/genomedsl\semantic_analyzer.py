"""
Semantic Analyzer for GenomeDSL.
Performs biological type checking, alphabet validation, and symbol table resolution.
Distinguishes DNA, RNA, and Protein as first-class biological types before execution.
"""

from typing import Optional, Set
from genomedsl.ast_nodes import (
    Program,
    Statement,
    VarDecl,
    AssignStmt,
    PrintStmt,
    PlotStmt,
    Expr,
    Literal,
    Identifier,
    FunctionCall,
)
from genomedsl.symbol_table import SymbolTable, Symbol, VALID_TYPES
from genomedsl.errors import (
    SemanticError,
    BiologicalTypeError,
    AlphabetError,
)

# Canonical biological alphabets
DNA_ALPHABET: Set[str] = {"A", "C", "G", "T"}
RNA_ALPHABET: Set[str] = {"A", "C", "G", "U"}

# Standard 20 Amino Acids (+ '*' for stop codon)
# Reserved for student implementation verification in Task 1
STANDARD_PROTEIN_ALPHABET: Set[str] = {
    "A", "C", "D", "E", "F", "G", "H", "I", "K", "L",
    "M", "N", "P", "Q", "R", "S", "T", "V", "W", "Y", "*"
}


class SemanticAnalyzer:
    """
    Performs type checking and biological validation on the GenomeDSL AST.
    Decorates AST nodes with inferred biological types.
    """

    def __init__(self, student_mode: bool = False):
        self.symbol_table = SymbolTable()
        self.student_mode = student_mode
        self.errors = []

    def analyze(self, program: Program) -> SymbolTable:
        """Runs complete semantic analysis on a program."""
        for stmt in program.statements:
            self.visit_statement(stmt)
        return self.symbol_table

    def visit_statement(self, stmt: Statement) -> None:
        if isinstance(stmt, VarDecl):
            self.visit_var_decl(stmt)
        elif isinstance(stmt, AssignStmt):
            self.visit_assign_stmt(stmt)
        elif isinstance(stmt, PrintStmt):
            self.visit_print_stmt(stmt)
        elif isinstance(stmt, PlotStmt):
            self.visit_plot_stmt(stmt)
        else:
            raise SemanticError(f"Unknown statement type: {stmt.__class__.__name__}", line=stmt.line, column=stmt.column)

    def visit_var_decl(self, stmt: VarDecl) -> None:
        if stmt.type_name not in VALID_TYPES:
            raise SemanticError(
                f"Unknown type '{stmt.type_name}'. Expected one of: {', '.join(sorted(VALID_TYPES))}",
                line=stmt.line,
                column=stmt.column,
            )

        # Type-check the initialization expression
        expr_type = self.visit_expr(stmt.expr)

        # Validate literal alphabets if assigning string literal
        if isinstance(stmt.expr, Literal) and stmt.expr.lit_type == "STRING":
            self._validate_literal_alphabet(stmt.type_name, stmt.expr.value, stmt.line, stmt.column)

        # Check biological type compatibility
        if stmt.type_name != "RESULT" and expr_type != "RESULT":
            if stmt.type_name != expr_type:
                raise BiologicalTypeError(
                    f"Cannot assign expression of biological type '{expr_type}' to variable '{stmt.var_name}' of type '{stmt.type_name}'",
                    line=stmt.line,
                    column=stmt.column,
                )

        symbol = Symbol(
            name=stmt.var_name,
            type_name=stmt.type_name,
            line=stmt.line,
            column=stmt.column,
        )
        self.symbol_table.define(symbol)

    def visit_assign_stmt(self, stmt: AssignStmt) -> None:
        sym = self.symbol_table.lookup(stmt.var_name)
        if not sym:
            raise SemanticError(
                f"Cannot assign to undeclared variable '{stmt.var_name}'",
                line=stmt.line,
                column=stmt.column,
            )

        expr_type = self.visit_expr(stmt.expr)

        if isinstance(stmt.expr, Literal) and stmt.expr.lit_type == "STRING":
            self._validate_literal_alphabet(sym.type_name, stmt.expr.value, stmt.line, stmt.column)

        if sym.type_name != "RESULT" and expr_type != "RESULT":
            if sym.type_name != expr_type:
                raise BiologicalTypeError(
                    f"Cannot assign expression of type '{expr_type}' to variable '{stmt.var_name}' of type '{sym.type_name}'",
                    line=stmt.line,
                    column=stmt.column,
                )

    def visit_print_stmt(self, stmt: PrintStmt) -> None:
        for expr in stmt.expressions:
            self.visit_expr(expr)

    def visit_plot_stmt(self, stmt: PlotStmt) -> None:
        call = stmt.call
        if not isinstance(call, FunctionCall):
            raise SemanticError(
                "PLOT statement requires a function call expression, e.g. PLOT gc_content(seq)",
                line=stmt.line,
                column=stmt.column,
            )
        self.visit_function_call(call)
        if call.name != "gc_content":
            raise SemanticError(
                f"PLOT statement currently supports 'gc_content', got '{call.name}'",
                line=stmt.line,
                column=stmt.column,
            )

    def visit_expr(self, expr: Expr) -> str:
        """Visits an expression, infers its biological type, and attaches it."""
        inferred = "RESULT"
        if isinstance(expr, Literal):
            if expr.lit_type == "STRING":
                inferred = "RESULT"  # Default unless constrained by declaration
            elif expr.lit_type in ("INT", "FLOAT"):
                inferred = "RESULT"
        elif isinstance(expr, Identifier):
            sym = self.symbol_table.lookup(expr.name)
            if not sym:
                raise SemanticError(
                    f"Variable '{expr.name}' is not declared before use",
                    line=expr.line,
                    column=expr.column,
                )
            inferred = sym.type_name
        elif isinstance(expr, FunctionCall):
            inferred = self.visit_function_call(expr)
        else:
            raise SemanticError(f"Unknown expression node: {expr.__class__.__name__}", line=expr.line, column=expr.column)

        expr.inferred_type = inferred
        return inferred

    def visit_function_call(self, call: FunctionCall) -> str:
        name = call.name

        # Evaluate argument types
        arg_types = [self.visit_expr(arg) for arg in call.args]

        if name == "transcribe":
            if len(call.args) != 1:
                raise SemanticError(f"transcribe() expects exactly 1 argument, got {len(call.args)}", line=call.line, column=call.column)
            if arg_types[0] != "DNA":
                raise BiologicalTypeError(
                    f"transcribe() requires DNA sequence, got '{arg_types[0]}'",
                    line=call.line,
                    column=call.column,
                )
            call.inferred_type = "RNA"
            return "RNA"

        elif name == "translate":
            if len(call.args) != 1:
                raise SemanticError(f"translate() expects exactly 1 argument, got {len(call.args)}", line=call.line, column=call.column)
            if arg_types[0] != "RNA":
                raise BiologicalTypeError(
                    f"translate() requires RNA sequence, got '{arg_types[0]}'",
                    line=call.line,
                    column=call.column,
                )
            # =====================================================================
            # STUDENT ZONE - Task 1 (Optional refinement):
            # Check codon divisibility or partial codon warnings for translate()
            # =====================================================================
            call.inferred_type = "Protein"
            return "Protein"

        elif name == "reverse_complement":
            if len(call.args) != 1:
                raise SemanticError(f"reverse_complement() expects 1 argument, got {len(call.args)}", line=call.line, column=call.column)
            if arg_types[0] == "Protein":
                raise BiologicalTypeError(
                    "reverse_complement() is not defined for Protein sequences",
                    line=call.line,
                    column=call.column,
                )
            call.inferred_type = arg_types[0] if arg_types[0] in ("DNA", "RNA") else "DNA"
            return call.inferred_type

        elif name == "reverse":
            if len(call.args) != 1:
                raise SemanticError(f"reverse() expects 1 argument, got {len(call.args)}", line=call.line, column=call.column)
            call.inferred_type = arg_types[0]
            return call.inferred_type

        elif name == "gc_content":
            if len(call.args) != 1:
                raise SemanticError(f"gc_content() expects 1 argument, got {len(call.args)}", line=call.line, column=call.column)
            if arg_types[0] == "Protein":
                raise BiologicalTypeError(
                    "gc_content() is only defined for DNA or RNA, got 'Protein'",
                    line=call.line,
                    column=call.column,
                )
            call.inferred_type = "RESULT"
            return "RESULT"

        elif name == "find_motif":
            if len(call.args) != 2:
                raise SemanticError(f"find_motif() expects 2 arguments (sequence, motif), got {len(call.args)}", line=call.line, column=call.column)
            # Motif search can be run on DNA, RNA, or Protein
            call.inferred_type = "RESULT"
            return "RESULT"

        elif name in ("compare", "similarity"):
            # =====================================================================
            # STUDENT ZONE - Task 2: Type checking for sequence comparison
            # Verify that both sequences have the same biological type!
            # Example: DNA with DNA, RNA with RNA, Protein with Protein.
            # =====================================================================
            if len(call.args) != 2:
                raise SemanticError(f"{name}() expects 2 arguments (seq1, seq2), got {len(call.args)}", line=call.line, column=call.column)
            
            # Delegate to student implementation helper
            self._check_sequence_comparison_semantics(call, arg_types[0], arg_types[1])
            call.inferred_type = "RESULT"
            return "RESULT"

        elif name == "length":
            if len(call.args) != 1:
                raise SemanticError(f"length() expects 1 argument, got {len(call.args)}", line=call.line, column=call.column)
            call.inferred_type = "RESULT"
            return "RESULT"

        else:
            raise SemanticError(f"Unknown function '{name}'", line=call.line, column=call.column)

    def _validate_literal_alphabet(self, type_name: str, value: str, line: Optional[int], column: Optional[int]) -> None:
        """Validates that a string literal adheres to the biological alphabet."""
        clean_val = value.strip().upper()
        if type_name == "DNA":
            for char in clean_val:
                if char not in DNA_ALPHABET:
                    raise AlphabetError(
                        f"Invalid DNA base '{char}'. DNA sequences only accept bases: A, T, G, C",
                        line=line,
                        column=column,
                    )
        elif type_name == "RNA":
            for char in clean_val:
                if char not in RNA_ALPHABET:
                    raise AlphabetError(
                        f"Invalid RNA base '{char}'. RNA sequences only accept bases: A, U, G, C",
                        line=line,
                        column=column,
                    )
        elif type_name == "Protein":
            # =====================================================================
            # STUDENT ZONE - Task 1: Protein alphabet validation
            # =====================================================================
            self._validate_protein_alphabet(clean_val, line, column)

    def _validate_protein_alphabet(self, seq: str, line: Optional[int], column: Optional[int]) -> None:
        """
        Validates that every character in the sequence belongs to STANDARD_PROTEIN_ALPHABET
        (the 20 standard amino acids + '*').
        Raises AlphabetError if any non-standard residue is found.
        """
        for char in seq.strip().upper():
            if char not in STANDARD_PROTEIN_ALPHABET:
                raise AlphabetError(
                    f"Invalid amino acid '{char}'. Protein sequences only accept standard amino acid single-letter codes",
                    line=line,
                    column=column,
                )

    def _check_sequence_comparison_semantics(self, call: FunctionCall, type1: str, type2: str) -> None:
        """
        STUDENT IMPLEMENTATION HOOK - Task 2:
        Ensures that sequence comparison operations only compare sequences of the same biological type.
        (e.g., DNA with DNA, RNA with RNA, Protein with Protein).
        """
        # When comparing two known types, they must be equal:
        if type1 != "RESULT" and type2 != "RESULT" and type1 != type2:
            raise BiologicalTypeError(
                f"Cannot compare sequences of differing biological types: '{type1}' vs '{type2}'",
                line=call.line,
                column=call.column,
            )


def analyze_code(program: Program) -> SymbolTable:
    """Convenience helper to run semantic analysis."""
    analyzer = SemanticAnalyzer()
    analyzer.analyze(program)
    return analyzer.symbol_table
