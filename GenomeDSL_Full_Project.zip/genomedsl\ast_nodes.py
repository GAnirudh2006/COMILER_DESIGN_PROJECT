"""
Abstract Syntax Tree (AST) node definitions for GenomeDSL.
Implemented using Python dataclasses for clean pattern matching, readability, and compiler phase decoupling.
"""

from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class ASTNode:
    """Base class for all AST nodes with source location metadata."""
    line: Optional[int] = None
    column: Optional[int] = None


@dataclass
class Expr(ASTNode):
    """Base class for all expression nodes."""
    inferred_type: Optional[str] = field(default=None, init=False)


@dataclass
class Literal(Expr):
    """Literal values: String literals ('ATGC'), Integers, Floats."""
    value: Any = None
    lit_type: str = "STRING"  # 'STRING', 'INT', 'FLOAT'


@dataclass
class Identifier(Expr):
    """Variable reference node."""
    name: str = ""


@dataclass
class FunctionCall(Expr):
    """Function invocation: transcribe(gene), gc_content(gene), etc."""
    name: str = ""
    args: List[Expr] = field(default_factory=list)


@dataclass
class Statement(ASTNode):
    """Base class for statements."""
    pass


@dataclass
class VarDecl(Statement):
    """Variable declaration: DNA gene = 'ATGCGTAC'"""
    type_name: str = ""
    var_name: str = ""
    expr: Expr = field(default_factory=Literal)


@dataclass
class AssignStmt(Statement):
    """Assignment to existing variable: gene = reverse(gene)"""
    var_name: str = ""
    expr: Expr = field(default_factory=Literal)


@dataclass
class PrintStmt(Statement):
    """Output statement: PRINT gene or PRINT 'GC content:', gc"""
    expressions: List[Expr] = field(default_factory=list)


@dataclass
class PlotStmt(Statement):
    """Plotting statement: PLOT gc_content(gene)"""
    call: FunctionCall = field(default_factory=FunctionCall)


@dataclass
class Program(ASTNode):
    """Root node representing a full GenomeDSL program."""
    statements: List[Statement] = field(default_factory=list)

    def pretty(self, indent: int = 0) -> str:
        """Pretty-prints the AST hierarchy for compiler diagnostics."""
        lines = [" " * indent + f"Program ({len(self.statements)} statements):"]
        for stmt in self.statements:
            lines.append(self._format_node(stmt, indent + 2))
        return "\n".join(lines)

    @classmethod
    def _format_node(cls, node: ASTNode, indent: int) -> str:
        pad = " " * indent
        loc = f" [L{node.line}:C{node.column}]" if node.line else ""
        if isinstance(node, VarDecl):
            return f"{pad}VarDecl({node.type_name} {node.var_name}){loc}\n{cls._format_node(node.expr, indent + 2)}"
        elif isinstance(node, AssignStmt):
            return f"{pad}AssignStmt({node.var_name}){loc}\n{cls._format_node(node.expr, indent + 2)}"
        elif isinstance(node, PrintStmt):
            expr_strs = "\n".join(cls._format_node(e, indent + 2) for e in node.expressions)
            return f"{pad}PrintStmt{loc}:\n{expr_strs}"
        elif isinstance(node, PlotStmt):
            return f"{pad}PlotStmt{loc}:\n{cls._format_node(node.call, indent + 2)}"
        elif isinstance(node, FunctionCall):
            args_str = "\n".join(cls._format_node(a, indent + 2) for a in node.args)
            return f"{pad}FunctionCall({node.name}){loc}:\n{args_str}" if node.args else f"{pad}FunctionCall({node.name}()){loc}"
        elif isinstance(node, Identifier):
            return f"{pad}Identifier({node.name}){loc}"
        elif isinstance(node, Literal):
            return f"{pad}Literal({node.lit_type}: {repr(node.value)}){loc}"
        return f"{pad}{node.__class__.__name__}{loc}"
