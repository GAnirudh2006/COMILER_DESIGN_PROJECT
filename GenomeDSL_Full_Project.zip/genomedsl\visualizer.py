"""
Output and Visualization module for GenomeDSL.
Generates publication-quality charts for biological sequence analyses using Matplotlib.
Supports sliding-window GC-content profiles and nucleotide distribution charts.
"""

import os
import matplotlib
# Use Agg backend for non-interactive / headless environment rendering
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Optional


def compute_sliding_window_gc(seq: str, window_size: int = 10, step: int = 1):
    """Calculates sliding window GC percentages across a sequence."""
    seq = seq.upper()
    n = len(seq)
    if n == 0:
        return [], []
    if window_size > n:
        window_size = max(1, n)

    positions = []
    gc_values = []

    for i in range(0, n - window_size + 1, step):
        window = seq[i : i + window_size]
        gc = ((window.count("G") + window.count("C")) / len(window)) * 100.0
        # Position represents center of current window
        positions.append(i + window_size // 2)
        gc_values.append(gc)

    return positions, gc_values


def plot_gc_content_window(
    sequence: str,
    title: str = "GC-Content Sliding Window Profile",
    window_size: int = 10,
    output_dir: Optional[str] = None,
    filename: str = "gc_profile.png",
) -> str:
    """
    Renders a GC-content sliding window profile and base distribution chart.
    Saves the result to an image file and returns its path.
    """
    if not output_dir:
        output_dir = os.path.join(os.getcwd(), "evidence")
    os.makedirs(output_dir, exist_ok=True)
    out_path = os.path.join(output_dir, filename)

    clean_seq = sequence.upper().strip()
    if not clean_seq:
        return ""

    # Adjust window size dynamically for short sequences
    actual_window = min(window_size, max(3, len(clean_seq) // 4)) if len(clean_seq) < 30 else window_size
    positions, gc_vals = compute_sliding_window_gc(clean_seq, window_size=actual_window)

    overall_gc = ((clean_seq.count("G") + clean_seq.count("C")) / len(clean_seq)) * 100.0

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), gridspec_kw={"height_ratios": [2.5, 1.2]})

    # Subplot 1: Sliding Window GC Line Plot
    if positions and gc_vals:
        ax1.plot(positions, gc_vals, color="#2b5c8f", linewidth=2.0, label=f"Sliding GC% (window={actual_window}bp)")
        ax1.fill_between(positions, gc_vals, overall_gc, alpha=0.15, color="#4184c4")
    ax1.axhline(overall_gc, color="#d9534f", linestyle="--", linewidth=1.5, label=f"Average GC ({overall_gc:.1f}%)")
    ax1.set_title(title, fontsize=12, fontweight="bold", pad=10)
    ax1.set_xlabel("Sequence Coordinate (bp)", fontsize=10)
    ax1.set_ylabel("GC Percentage (%)", fontsize=10)
    ax1.set_ylim(-5, 105)
    ax1.grid(True, linestyle=":", alpha=0.6)
    ax1.legend(loc="upper right", frameon=True, fontsize=9)

    # Subplot 2: Base Distribution Bar Chart
    bases = ["A", "T", "G", "C", "U"]
    counts = [clean_seq.count(b) for b in bases]
    # Filter out bases with 0 count (e.g. U in DNA or T in RNA)
    active_pairs = [(b, c) for b, c in zip(bases, counts) if c > 0]
    if active_pairs:
        labels, freqs = zip(*active_pairs)
        palette = {"A": "#5cb85c", "T": "#d9534f", "G": "#f0ad4e", "C": "#0275d8", "U": "#9b59b6"}
        bar_colors = [palette.get(b, "#888888") for b in labels]
        bars = ax2.bar(labels, freqs, color=bar_colors, width=0.5, edgecolor="black", linewidth=0.8)
        ax2.set_title("Nucleotide Composition", fontsize=10, fontweight="bold")
        ax2.set_ylabel("Count", fontsize=9)
        ax2.grid(axis="y", linestyle=":", alpha=0.5)
        for bar in bars:
            h = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width() / 2.0, h + 0.1, f"{h}", ha="center", va="bottom", fontsize=8)

    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path
