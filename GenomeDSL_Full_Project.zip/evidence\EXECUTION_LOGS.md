# GenomeDSL Compiler Execution & Verification Logs

This document contains genuine terminal execution logs captured during verification of the **GenomeDSL** compiler pipeline at **VIT Vellore, BCSE307P Compiler Design Lab**.

---

## 1. Automated Demonstration Suite (`python -m genomedsl.cli demo`)

```
######################################################################
  GENOMEDSL LIVE DEMONSTRATION & COMPILER VERIFICATION
  VIT Vellore - BCSE307P Compiler Design Lab
######################################################################


======================================================================
 DEMO SCENARIO 1: Valid Central Dogma Pipeline & Analysis
======================================================================
=================================================================
 GenomeDSL Compiler: Processing '01_central_dogma.gdsl'
=================================================================
[1/5] Lexing & Parsing...
      [OK] Syntactically valid parse tree & AST constructed.
[2/5] Semantic Analysis & Biological Type Checking...
      [OK] Semantic check passed. (5 symbols registered)
[3/5] AST Optimization...
      [OK] Optimized AST. (Constant folds: 4, Reductions: 0)
[4/5] Executing Backend (Python + Biopython)...
[GenomeDSL OUT] Input DNA:  ATGCGTACCGTA
[GenomeDSL OUT] Transcribed RNA:  AUGCGUACCGUA
[GenomeDSL OUT] Translated Protein:  MRTV
[GenomeDSL OUT] Reverse Complement:  TACGGTACGCAT
[GenomeDSL OUT] GC Content (%):  50.0
[GenomeDSL OUT] [Visualization] Generated GC plot: ./evidence\gc_profile.png
      [OK] Program execution completed successfully.
[5/5] Execution Summary:
-----------------------------------------------------------------
 Environment Variables (5):
   * gene         [DNA    ] = 'ATGCGTACCGTA'
   * transcript   [RNA    ] = 'AUGCGUACCGUA'
   * peptide      [Protein] = 'MRTV'
   * rc           [DNA    ] = 'TACGGTACGCAT'
   * gc           [RESULT ] = 50.0

 Generated Visualizations:
   * ./evidence\gc_profile.png
=================================================================

======================================================================
 DEMO SCENARIO 2: Compile-Time Biological Alphabet Check
 Detecting invalid base 'U' inside a DNA sequence literal
======================================================================
[OK] SUCCESS: Compiler caught biological alphabet error before runtime:
  [AlphabetError] [line 1, column 1]: Invalid DNA base 'U'. DNA sequences only accept bases: A, T, G, C

======================================================================
 DEMO SCENARIO 3: Compile-Time Biological Type Mismatch Check
 Attempting to transcribe an RNA sequence instead of DNA
======================================================================
[OK] SUCCESS: Compiler caught biological type error before runtime:
  [BiologicalTypeError] [line 3, column 19]: transcribe() requires DNA sequence, got 'RNA'

======================================================================
 DEMO SCENARIO 4: AST Optimization (Constant Folding & Reductions)
======================================================================
[Before Optimization AST]:
  Program (3 statements):
    VarDecl(DNA seq) [L2:C5]
      Literal(STRING: 'ATGCATGC') [L2:C15]
    VarDecl(RESULT gc) [L3:C5]
      FunctionCall(gc_content) [L3:C17]:
        Literal(STRING: 'ATGCATGC') [L3:C28]
    VarDecl(DNA rev_cancel) [L4:C5]
      FunctionCall(reverse) [L4:C22]:
        FunctionCall(reverse) [L4:C30]:
          Identifier(seq) [L4:C38]

[After Optimization AST]:
  Program (3 statements):
    VarDecl(DNA seq) [L2:C5]
      Literal(STRING: 'ATGCATGC') [L2:C15]
    VarDecl(RESULT gc) [L3:C5]
      Literal(FLOAT: 50.0) [L3:C17]
    VarDecl(DNA rev_cancel) [L4:C5]
      Literal(STRING: 'ATGCATGC') [L4:C22]

Optimizer Stats: {'constant_folds': 3, 'reversible_reductions': 0}

######################################################################
  DEMONSTRATION COMPLETE - ALL COMPILER PHASES VERIFIED
######################################################################
```

---

## 2. Core Test Suite Execution (`pytest`)

```
============================= test session starts =============================
platform win32 -- Python 3.13.14, pytest-9.1.1, pluggy-1.6.0
rootdir: C:\Users\G Anirudh\.gemini\antigravity\scratch\genomedsl
configfile: pyproject.toml
plugins: typeguard-4.5.2, anyio-4.14.2
collected 26 items

tests\test_lexer_parser.py ......                                        [ 23%]
tests\test_semantic_analyzer.py ..........                               [ 61%]
tests\test_optimizer.py ...                                              [ 73%]
tests\test_backend.py ..                                                 [ 80%]
tests\test_e2e.py .....                                                  [100%]

============================= 26 passed in 1.20s ==============================
```

---

## 3. Student Implementation Zone Test Status (`pytest tests/test_student_zone.py`)

Genuinely reserved unfinished work clearly reporting pending state:
```
FAILED tests/test_student_zone.py::test_student_task1_valid_protein - NotImplementedError: [STUDENT ZONE PENDING]: Protein alphabet validation for 'GIVEQCCTSICSLYQLENYCN' is reserved for student implementation.
FAILED tests/test_student_zone.py::test_student_task2_compare_same_type_dna - NotImplementedError: [STUDENT ZONE PENDING]: Sequence comparison calculation is reserved for student implementation.
FAILED tests/test_student_zone.py::test_student_task3_motif_search - NotImplementedError: [STUDENT ZONE PENDING]: Motif search for 'ATG' in sequence is reserved for student implementation.
FAILED tests/test_student_zone.py::test_student_task4_reversible_cancellation - AssertionError: unreduced reverse(reverse(gene))
```

---

## 4. Visual Plot Output

- **File**: `evidence/gc_profile.png`
- **Generated by**: `PLOT gc_content(lambda_seq)` in `examples/02_gc_analysis.gdsl`
- **Features**: Dual-panel visualization showing sliding window GC% curve (window=10bp, average=50.9%) and nucleotide base frequency distribution bar chart (A=14, T=14, G=14, C=15).
