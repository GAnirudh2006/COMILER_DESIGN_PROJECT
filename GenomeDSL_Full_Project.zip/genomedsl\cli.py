"""
Command Line Interface (CLI) for GenomeDSL.
Provides developer and demonstration subcommands:
- run: Parse, semantically validate, optimize, and execute a GenomeDSL script.
- check: Perform biological semantic type checking without execution.
- ast: Display the formatted Abstract Syntax Tree.
- optimize: Display the optimized AST and optimization statistics.
- demo: Run an automated end-to-end demonstration showcasing language features and errors.
"""

import sys
import os
import argparse
from typing import Optional

from genomedsl.parser import parse_code
from genomedsl.semantic_analyzer import analyze_code
from genomedsl.optimizer import ASTOptimizer
from genomedsl.backend import ExecutionBackend
from genomedsl.errors import GenomeDSLError


def run_pipeline(source_code: str, file_name: str = "<stdin>", optimize: bool = True, output_dir: Optional[str] = None):
    """Executes the full GenomeDSL compilation and execution pipeline."""
    print("=" * 65)
    print(f" GenomeDSL Compiler: Processing '{file_name}'")
    print("=" * 65)

    # Phase 1: Lexical and Syntactic Analysis
    print("[1/5] Lexing & Parsing...")
    try:
        ast = parse_code(source_code)
        print("      [OK] Syntactically valid parse tree & AST constructed.")
    except GenomeDSLError as e:
        print(f"\n{e.format_error()}")
        return False, None

    # Phase 2: Semantic Analysis & Biological Type Checking
    print("[2/5] Semantic Analysis & Biological Type Checking...")
    try:
        sym_table = analyze_code(ast)
        print(f"      [OK] Semantic check passed. ({len(sym_table.all_symbols())} symbols registered)")
    except NotImplementedError as e:
        print(f"\n[STUDENT RESERVED ZONE]: {str(e)}")
        return False, None
    except GenomeDSLError as e:
        print(f"\n{e.format_error()}")
        return False, None

    # Phase 3: AST Optimization
    if optimize:
        print("[3/5] AST Optimization...")
        opt = ASTOptimizer()
        try:
            ast = opt.optimize(ast)
            print(f"      [OK] Optimized AST. (Constant folds: {opt.stats['constant_folds']}, Reductions: {opt.stats['reversible_reductions']})")
        except NotImplementedError as e:
            print(f"\n[STUDENT RESERVED ZONE]: {str(e)}")
            return False, None
    else:
        print("[3/5] Skipping AST Optimization.")

    # Phase 4 & 5: Backend Execution & Output Generation
    print("[4/5] Executing Backend (Python + Biopython)...")
    backend = ExecutionBackend(visual_output_dir=output_dir)
    try:
        backend.execute(ast)
        print("      [OK] Program execution completed successfully.")
    except NotImplementedError as e:
        print(f"\n[STUDENT RESERVED ZONE]: {str(e)}")
        return False, None
    except GenomeDSLError as e:
        print(f"\n{e.format_error()}")
        return False, None

    print("[5/5] Execution Summary:")
    print("-" * 65)
    print(f" Environment Variables ({len(backend.env)}):")
    for name, (val, t) in backend.env.items():
        val_display = f"'{val}'" if isinstance(val, str) else str(val)
        print(f"   * {name:12} [{t:7}] = {val_display}")

    if backend.generated_plots:
        print("\n Generated Visualizations:")
        for plot in backend.generated_plots:
            print(f"   * {plot}")
    print("=" * 65)
    return True, backend


def main():
    parser = argparse.ArgumentParser(
        prog="genomedsl",
        description="GenomeDSL: Domain-Specific Programming Language for DNA, RNA and Protein Analysis",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Command: run
    run_parser = subparsers.add_parser("run", help="Run a GenomeDSL source file")
    run_parser.add_argument("file", help="Path to .gdsl script")
    run_parser.add_argument("--no-opt", action="store_true", help="Disable AST optimization")
    run_parser.add_argument("--out-dir", default="./evidence", help="Directory for generated plots")

    # Command: check
    check_parser = subparsers.add_parser("check", help="Type-check a script without executing")
    check_parser.add_argument("file", help="Path to .gdsl script")

    # Command: ast
    ast_parser = subparsers.add_parser("ast", help="Display the Abstract Syntax Tree")
    ast_parser.add_argument("file", help="Path to .gdsl script")

    # Command: optimize
    opt_parser = subparsers.add_parser("optimize", help="Display the optimized AST")
    opt_parser.add_argument("file", help="Path to .gdsl script")

    # Command: demo
    subparsers.add_parser("demo", help="Run the automated demonstration suite")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "demo":
        from genomedsl.demo import run_demo
        run_demo()
        sys.exit(0)

    if not os.path.exists(args.file):
        print(f"Error: File not found: {args.file}")
        sys.exit(1)

    with open(args.file, "r", encoding="utf-8") as f:
        code = f.read()

    if args.command == "ast":
        try:
            ast = parse_code(code)
            print(ast.pretty())
        except GenomeDSLError as e:
            print(e.format_error())
            sys.exit(1)

    elif args.command == "optimize":
        try:
            ast = parse_code(code)
            analyze_code(ast)
            opt = ASTOptimizer()
            opt_ast = opt.optimize(ast)
            print(opt_ast.pretty())
            print(f"\nOptimization Statistics: {opt.stats}")
        except NotImplementedError as e:
            print(f"[STUDENT RESERVED ZONE]: {str(e)}")
            sys.exit(0)
        except GenomeDSLError as e:
            print(e.format_error())
            sys.exit(1)

    elif args.command == "check":
        try:
            ast = parse_code(code)
            sym = analyze_code(ast)
            print(f"SUCCESS: '{args.file}' passed all biological semantic checks.")
            print(f"Declared symbols: {list(sym.all_symbols().keys())}")
        except NotImplementedError as e:
            print(f"[STUDENT RESERVED ZONE]: {str(e)}")
            sys.exit(0)
        except GenomeDSLError as e:
            print(e.format_error())
            sys.exit(1)

    elif args.command == "run":
        success, _ = run_pipeline(
            source_code=code,
            file_name=args.file,
            optimize=not args.no_opt,
            output_dir=args.out_dir,
        )
        sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
