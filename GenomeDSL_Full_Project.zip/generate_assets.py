"""
Generate high-resolution, local SVG diagrams for GenomeDSL
with an authentic Soft English Editorial aesthetic.
"""

import os

os.makedirs("assets", exist_ok=True)

# 1. Central Dogma of Molecular Biology Diagram
svg_dogma = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 860 210" width="100%" height="210">
  <defs>
    <linearGradient id="dnaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#3d5a45" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#24382b" stop-opacity="0.95"/>
    </linearGradient>
    <linearGradient id="rnaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#2f4866" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#1a2b3d" stop-opacity="0.95"/>
    </linearGradient>
    <linearGradient id="proteinGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#563f61" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#35233d" stop-opacity="0.95"/>
    </linearGradient>
    <marker id="arrow1" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 10 5 L 0 9 z" fill="#8FA895"/>
    </marker>
    <marker id="arrow2" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 10 5 L 0 9 z" fill="#748CAB"/>
    </marker>
  </defs>

  <!-- Background Canvas -->
  <rect x="2" y="2" width="856" height="206" rx="12" fill="#141822" stroke="#2a3345" stroke-width="1.2"/>

  <!-- DNA Box -->
  <g transform="translate(30, 35)">
    <rect width="215" height="135" rx="9" fill="url(#dnaGrad)" stroke="#8FA895" stroke-width="1.4"/>
    <text x="107" y="38" fill="#FFFFFF" font-family="'Georgia', serif" font-size="22" font-weight="bold" text-anchor="middle">DNA</text>
    <text x="107" y="64" fill="#d2e3d7" font-family="sans-serif" font-size="12" text-anchor="middle">Deoxyribonucleic Acid</text>
    <rect x="25" y="84" width="165" height="28" rx="5" fill="#17241b" opacity="0.8"/>
    <text x="107" y="103" fill="#a4cfb0" font-family="monospace" font-size="12.5" font-weight="bold" text-anchor="middle">Alphabet: { A, T, G, C }</text>
  </g>

  <!-- Transcription Arrow & Tag -->
  <path d="M 255 102 L 325 102" stroke="#8FA895" stroke-width="2.5" stroke-dasharray="6,3" marker-end="url(#arrow1)"/>
  <rect x="255" y="65" width="85" height="26" rx="5" fill="#1d2b21" stroke="#8FA895" stroke-width="1"/>
  <text x="297" y="82" fill="#CDE8D5" font-family="'JetBrains Mono', monospace" font-size="10.5" font-weight="bold" text-anchor="middle">transcribe()</text>

  <!-- RNA Box -->
  <g transform="translate(330, 35)">
    <rect width="215" height="135" rx="9" fill="url(#rnaGrad)" stroke="#748CAB" stroke-width="1.4"/>
    <text x="107" y="38" fill="#FFFFFF" font-family="'Georgia', serif" font-size="22" font-weight="bold" text-anchor="middle">RNA</text>
    <text x="107" y="64" fill="#d0dfef" font-family="sans-serif" font-size="12" text-anchor="middle">Ribonucleic Acid (mRNA)</text>
    <rect x="25" y="84" width="165" height="28" rx="5" fill="#142130" opacity="0.8"/>
    <text x="107" y="103" fill="#99bfeb" font-family="monospace" font-size="12.5" font-weight="bold" text-anchor="middle">Alphabet: { A, U, G, C }</text>
  </g>

  <!-- Translation Arrow & Tag -->
  <path d="M 555 102 L 625 102" stroke="#748CAB" stroke-width="2.5" stroke-dasharray="6,3" marker-end="url(#arrow2)"/>
  <rect x="560" y="65" width="80" height="26" rx="5" fill="#1b2838" stroke="#748CAB" stroke-width="1"/>
  <text x="600" y="82" fill="#C9DDF5" font-family="'JetBrains Mono', monospace" font-size="10.5" font-weight="bold" text-anchor="middle">translate()</text>

  <!-- Protein Box -->
  <g transform="translate(630, 35)">
    <rect width="195" height="135" rx="9" fill="url(#proteinGrad)" stroke="#AEA0C2" stroke-width="1.4"/>
    <text x="97" y="38" fill="#FFFFFF" font-family="'Georgia', serif" font-size="22" font-weight="bold" text-anchor="middle">PROTEIN</text>
    <text x="97" y="64" fill="#eadfef" font-family="sans-serif" font-size="12" text-anchor="middle">Polypeptide Chain</text>
    <rect x="20" y="84" width="155" height="28" rx="5" fill="#24162b" opacity="0.8"/>
    <text x="97" y="103" fill="#d2bddf" font-family="monospace" font-size="12" font-weight="bold" text-anchor="middle">20 Amino Acids + '*'</text>
  </g>
</svg>"""

# 2. Base Pairing Rules & Chemical Invariants
svg_pairing = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 860 170" width="100%" height="170">
  <!-- Background Card -->
  <rect x="2" y="2" width="856" height="166" rx="12" fill="#141822" stroke="#2a3345" stroke-width="1.2"/>

  <!-- Left: A = T -->
  <g transform="translate(35, 25)">
    <rect width="365" height="115" rx="8" fill="#1a231d" stroke="#4A6B53" stroke-width="1.2"/>
    <text x="20" y="36" fill="#8FA895" font-family="'Georgia', serif" font-size="16" font-weight="bold">Adenine (A) &bull; Thymine (T)</text>
    <text x="20" y="65" fill="#CDE8D5" font-family="monospace" font-size="20" font-weight="bold">A  = =  T</text>
    <text x="140" y="65" fill="#94a3b8" font-family="sans-serif" font-size="12">(2 Hydrogen Bonds)</text>
    <text x="20" y="98" fill="#94a3b8" font-family="sans-serif" font-size="11.5">In RNA, Thymine is replaced by Uracil: A = = U</text>
  </g>

  <!-- Right: G ≡ C -->
  <g transform="translate(440, 25)">
    <rect width="385" height="115" rx="8" fill="#1a202c" stroke="#3B5A80" stroke-width="1.2"/>
    <text x="20" y="36" fill="#748CAB" font-family="'Georgia', serif" font-size="16" font-weight="bold">Guanine (G) &bull; Cytosine (C)</text>
    <text x="20" y="65" fill="#99bfeb" font-family="monospace" font-size="20" font-weight="bold">G  &equiv; &equiv;  C</text>
    <text x="140" y="65" fill="#94a3b8" font-family="sans-serif" font-size="12">(3 Hydrogen Bonds &bull; Higher Tm)</text>
    <text x="20" y="98" fill="#94a3b8" font-family="sans-serif" font-size="11.5">Higher GC-content confers greater thermal stability</text>
  </g>
</svg>"""

with open("assets/central_dogma_diagram.svg", "w", encoding="utf-8") as f:
    f.write(svg_dogma)

with open("assets/dna_base_pairing.svg", "w", encoding="utf-8") as f:
    f.write(svg_pairing)

# 3. Compiler Pipeline Architectural SVG
svg_pipeline = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 920 220" width="100%" height="220">
  <defs>
    <marker id="pipeArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 10 5 L 0 9 z" fill="#84A98C"/>
    </marker>
  </defs>

  <rect x="2" y="2" width="916" height="216" rx="12" fill="#141923" stroke="#253041" stroke-width="1.2"/>

  <!-- Step 1: Source -->
  <g transform="translate(20, 30)">
    <rect width="140" height="155" rx="8" fill="#1A232E" stroke="#3A4D63" stroke-width="1.2"/>
    <text x="70" y="32" fill="#8EA8C3" font-family="'Cinzel', 'Georgia', serif" font-size="13" font-weight="bold" text-anchor="middle">SOURCE</text>
    <rect x="15" y="45" width="110" height="2" fill="#3A4D63"/>
    <text x="70" y="70" fill="#CBD5E1" font-family="'JetBrains Mono', monospace" font-size="11" text-anchor="middle">.gdsl Code</text>
    <text x="70" y="92" fill="#94A3B8" font-family="sans-serif" font-size="10.5" text-anchor="middle">DNA gene = ...</text>
    <rect x="18" y="112" width="104" height="24" rx="4" fill="#243345"/>
    <text x="70" y="128" fill="#748CAB" font-family="sans-serif" font-size="10" text-anchor="middle">User Program</text>
  </g>

  <!-- Arrow 1 -->
  <path d="M 165 107 L 195 107" stroke="#84A98C" stroke-width="2" marker-end="url(#pipeArrow)"/>

  <!-- Step 2: Lex & Parse -->
  <g transform="translate(200, 30)">
    <rect width="150" height="155" rx="8" fill="#1C2724" stroke="#4D6A56" stroke-width="1.2"/>
    <text x="75" y="32" fill="#A5C4AC" font-family="'Cinzel', 'Georgia', serif" font-size="13" font-weight="bold" text-anchor="middle">LARK PARSER</text>
    <rect x="15" y="45" width="120" height="2" fill="#4D6A56"/>
    <text x="75" y="70" fill="#D8E2DC" font-family="sans-serif" font-size="11" text-anchor="middle">Earley Grammar</text>
    <text x="75" y="92" fill="#94A3B8" font-family="'JetBrains Mono', monospace" font-size="10.5" text-anchor="middle">ASTBuilder</text>
    <rect x="18" y="112" width="114" height="24" rx="4" fill="#2D3E32"/>
    <text x="75" y="128" fill="#84A98C" font-family="sans-serif" font-size="10" text-anchor="middle">Typed AST Nodes</text>
  </g>

  <!-- Arrow 2 -->
  <path d="M 355 107 L 385 107" stroke="#84A98C" stroke-width="2" marker-end="url(#pipeArrow)"/>

  <!-- Step 3: Semantic Analysis -->
  <g transform="translate(390, 30)">
    <rect width="155" height="155" rx="8" fill="#292026" stroke="#7D3843" stroke-width="1.2"/>
    <text x="77" y="32" fill="#E2B6BD" font-family="'Cinzel', 'Georgia', serif" font-size="13" font-weight="bold" text-anchor="middle">SEMANTICS</text>
    <rect x="15" y="45" width="125" height="2" fill="#7D3843"/>
    <text x="77" y="70" fill="#EAD5D8" font-family="sans-serif" font-size="11" text-anchor="middle">Central Dogma</text>
    <text x="77" y="92" fill="#94A3B8" font-family="sans-serif" font-size="10.5" text-anchor="middle">Alphabet &amp; Scope</text>
    <rect x="18" y="112" width="119" height="24" rx="4" fill="#3D2831"/>
    <text x="77" y="128" fill="#D49A9B" font-family="sans-serif" font-size="10" text-anchor="middle">SymbolTable</text>
  </g>

  <!-- Arrow 3 -->
  <path d="M 550 107 L 580 107" stroke="#84A98C" stroke-width="2" marker-end="url(#pipeArrow)"/>

  <!-- Step 4: Optimizer -->
  <g transform="translate(585, 30)">
    <rect width="145" height="155" rx="8" fill="#2A241C" stroke="#A67C38" stroke-width="1.2"/>
    <text x="72" y="32" fill="#F0D290" font-family="'Cinzel', 'Georgia', serif" font-size="13" font-weight="bold" text-anchor="middle">OPTIMIZER</text>
    <rect x="15" y="45" width="115" height="2" fill="#A67C38"/>
    <text x="72" y="70" fill="#F4E8D1" font-family="sans-serif" font-size="11" text-anchor="middle">Constant Folding</text>
    <text x="72" y="92" fill="#94A3B8" font-family="sans-serif" font-size="10.5" text-anchor="middle">Reversible Red.</text>
    <rect x="15" y="112" width="115" height="24" rx="4" fill="#3D3222"/>
    <text x="72" y="128" fill="#E0B069" font-family="sans-serif" font-size="10" text-anchor="middle">Reduced AST</text>
  </g>

  <!-- Arrow 4 -->
  <path d="M 735 107 L 765 107" stroke="#84A98C" stroke-width="2" marker-end="url(#pipeArrow)"/>

  <!-- Step 5: Backend & Output -->
  <g transform="translate(770, 30)">
    <rect width="130" height="155" rx="8" fill="#1C2724" stroke="#4D6A56" stroke-width="1.2"/>
    <text x="65" y="32" fill="#A5C4AC" font-family="'Cinzel', 'Georgia', serif" font-size="13" font-weight="bold" text-anchor="middle">EXECUTION</text>
    <rect x="12" y="45" width="106" height="2" fill="#4D6A56"/>
    <text x="65" y="70" fill="#D8E2DC" font-family="sans-serif" font-size="11" text-anchor="middle">Biopython Seq</text>
    <text x="65" y="92" fill="#94A3B8" font-family="sans-serif" font-size="10.5" text-anchor="middle">Matplotlib Agg</text>
    <rect x="12" y="112" width="106" height="24" rx="4" fill="#2D3E32"/>
    <text x="65" y="128" fill="#84A98C" font-family="sans-serif" font-size="10" text-anchor="middle">Stdout + GC Plot</text>
  </g>
</svg>"""

with open("assets/compiler_pipeline.svg", "w", encoding="utf-8") as f:
    f.write(svg_pipeline)

print("Visual biological & compiler SVGs generated successfully in assets/.")
