"""
Demonstration runner for GenomeDSL.
Executes standard representative scenarios proving:
1. Valid Central Dogma pipeline execution.
2. Compile-time biological type check rejections.
3. Biological alphabet violation rejections.
4. AST optimization (constant folding and reversible operation reduction).
5. Plot generation for GC-content profile.
"""

from genomedsl.cli import run_pipeline
from genomedsl.parser import parse_code
from genomedsl.semantic_analyzer import analyze_code
from genomedsl.optimizer import ASTOptimizer
from genomedsl.errors import GenomeDSLError


def run_demo():
    print("\n" + "#" * 70)
    print("  GENOMEDSL LIVE DEMONSTRATION & COMPILER VERIFICATION")
    print("  VIT Vellore - BCSE307P Compiler Design Lab")
    print("#" * 70 + "\n")

    # Scenario 1: Standard Central Dogma Pipeline
    print("\n" + "=" * 70)
    print(" DEMO SCENARIO 1: Valid Central Dogma Pipeline & Analysis")
    print("=" * 70)
    valid_code = """
    DNA gene = "ATGCGTACCGTA"
    RNA transcript = transcribe(gene)
    Protein peptide = translate(transcript)
    DNA rc = reverse_complement(gene)
    RESULT gc = gc_content(gene)
    PRINT "Input DNA: ", gene
    PRINT "Transcribed RNA: ", transcript
    PRINT "Translated Protein: ", peptide
    PRINT "Reverse Complement: ", rc
    PRINT "GC Content (%): ", gc
    PLOT gc_content(gene)
    """
    run_pipeline(valid_code, file_name="01_central_dogma.gdsl", output_dir="./evidence")

    # Scenario 2: Biological Alphabet Violation Rejection (Compile-time)
    print("\n" + "=" * 70)
    print(" DEMO SCENARIO 2: Compile-Time Biological Alphabet Check")
    print(" Detecting invalid base 'U' inside a DNA sequence literal")
    print("=" * 70)
    alphabet_err_code = 'DNA bad_dna = "AUGCGTAC"'
    try:
        ast = parse_code(alphabet_err_code)
        analyze_code(ast)
        print("FAIL: Error was not detected!")
    except GenomeDSLError as e:
        print("[OK] SUCCESS: Compiler caught biological alphabet error before runtime:")
        print(f"  {e.format_error()}")

    # Scenario 3: Biological Type Mismatch Rejection (Compile-time)
    print("\n" + "=" * 70)
    print(" DEMO SCENARIO 3: Compile-Time Biological Type Mismatch Check")
    print(" Attempting to transcribe an RNA sequence instead of DNA")
    print("=" * 70)
    type_err_code = """
    RNA transcript = "AUGCCG"
    RNA illegal = transcribe(transcript)
    """
    try:
        ast = parse_code(type_err_code)
        analyze_code(ast)
        print("FAIL: Error was not detected!")
    except GenomeDSLError as e:
        print("[OK] SUCCESS: Compiler caught biological type error before runtime:")
        print(f"  {e.format_error()}")

    # Scenario 4: AST Optimization Demonstration
    print("\n" + "=" * 70)
    print(" DEMO SCENARIO 4: AST Optimization (Constant Folding & Reductions)")
    print("=" * 70)
    unoptimized_code = """
    DNA seq = "ATGCATGC"
    RESULT gc = gc_content("ATGCATGC")
    DNA rev_cancel = reverse(reverse(seq))
    """
    ast = parse_code(unoptimized_code)
    print("[Before Optimization AST]:")
    print(ast.pretty(indent=2))

    opt = ASTOptimizer()
    opt_ast = opt.optimize(ast)
    print("\n[After Optimization AST]:")
    print(opt_ast.pretty(indent=2))
    print(f"\nOptimizer Stats: {opt.stats}")

    print("\n" + "#" * 70)
    print("  DEMONSTRATION COMPLETE - ALL COMPILER PHASES VERIFIED")
    print("#" * 70 + "\n")


if __name__ == "__main__":
    run_demo()
