"""
Tests for GenomeDSL AST Optimizer.
Verifies constant folding and reversible operation reductions.
"""

from genomedsl.parser import parse_code
from genomedsl.optimizer import ASTOptimizer
from genomedsl.ast_nodes import Literal, Identifier


def test_constant_folding_gc_content():
    code = 'RESULT gc = gc_content("ATGC")'
    ast = parse_code(code)
    opt = ASTOptimizer()
    opt_ast = opt.optimize(ast)

    # Expression should be folded into a Literal(50.0)
    decl = opt_ast.statements[0]
    assert isinstance(decl.expr, Literal)
    assert decl.expr.value == 50.0
    assert opt.stats["constant_folds"] == 1


def test_constant_folding_transcribe():
    code = 'RNA r = transcribe("ATGC")'
    ast = parse_code(code)
    opt = ASTOptimizer()
    opt_ast = opt.optimize(ast)

    decl = opt_ast.statements[0]
    assert isinstance(decl.expr, Literal)
    assert decl.expr.value == "AUGC"
    assert opt.stats["constant_folds"] == 1


def test_constant_propagation_and_folding():
    code = """
    DNA gene = "ATGC"
    RESULT gc = gc_content(gene)
    """
    ast = parse_code(code)
    opt = ASTOptimizer()
    opt_ast = opt.optimize(ast)

    gc_decl = opt_ast.statements[1]
    assert isinstance(gc_decl.expr, Literal)
    assert gc_decl.expr.value == 50.0

