"""
Tests for GenomeDSL Semantic Analyzer.
Verifies biological type checking, alphabet validation, and symbol scoping.
"""

import pytest
from genomedsl.parser import parse_code
from genomedsl.semantic_analyzer import analyze_code
from genomedsl.errors import (
    SemanticError,
    BiologicalTypeError,
    AlphabetError,
)


def test_valid_central_dogma_pipeline():
    code = """
    DNA gene = "ATGCGTAC"
    RNA rna1 = transcribe(gene)
    Protein protein1 = translate(rna1)
    RESULT gc = gc_content(gene)
    DNA rc = reverse_complement(gene)
    """
    program = parse_code(code)
    sym_table = analyze_code(program)
    assert sym_table.is_defined("gene")
    assert sym_table.lookup("gene").type_name == "DNA"
    assert sym_table.lookup("rna1").type_name == "RNA"
    assert sym_table.lookup("protein1").type_name == "Protein"
    assert sym_table.lookup("gc").type_name == "RESULT"
    assert sym_table.lookup("rc").type_name == "DNA"


def test_invalid_dna_alphabet():
    code = 'DNA x = "AUGC"'
    program = parse_code(code)
    with pytest.raises(AlphabetError) as exc_info:
        analyze_code(program)
    assert "Invalid DNA base 'U'" in str(exc_info.value)


def test_invalid_rna_alphabet():
    code = 'RNA x = "ATGC"'
    program = parse_code(code)
    with pytest.raises(AlphabetError) as exc_info:
        analyze_code(program)
    assert "Invalid RNA base 'T'" in str(exc_info.value)


def test_transcribe_rejects_rna():
    code = """
    RNA r = "AUGC"
    RNA r2 = transcribe(r)
    """
    program = parse_code(code)
    with pytest.raises(BiologicalTypeError) as exc_info:
        analyze_code(program)
    assert "transcribe() requires DNA sequence, got 'RNA'" in str(exc_info.value)


def test_translate_rejects_dna():
    code = """
    DNA d = "ATGC"
    Protein p = translate(d)
    """
    program = parse_code(code)
    with pytest.raises(BiologicalTypeError) as exc_info:
        analyze_code(program)
    assert "translate() requires RNA sequence, got 'DNA'" in str(exc_info.value)


def test_gc_content_rejects_protein():
    code = """
    RNA r = "AUG"
    Protein p = translate(r)
    RESULT gc = gc_content(p)
    """
    program = parse_code(code)
    with pytest.raises(BiologicalTypeError) as exc_info:
        analyze_code(program)
    assert "gc_content() is only defined for DNA or RNA, got 'Protein'" in str(exc_info.value)


def test_reverse_complement_rejects_protein():
    code = """
    RNA r = "AUG"
    Protein p = translate(r)
    Protein p2 = reverse_complement(p)
    """
    program = parse_code(code)
    with pytest.raises(BiologicalTypeError) as exc_info:
        analyze_code(program)
    assert "reverse_complement() is not defined for Protein sequences" in str(exc_info.value)


def test_undeclared_variable():
    code = "RNA r = transcribe(missing_gene)"
    program = parse_code(code)
    with pytest.raises(SemanticError) as exc_info:
        analyze_code(program)
    assert "Variable 'missing_gene' is not declared before use" in str(exc_info.value)


def test_duplicate_declaration():
    code = """
    DNA gene = "ATGC"
    RNA gene = "AUGC"
    """
    program = parse_code(code)
    with pytest.raises(SemanticError) as exc_info:
        analyze_code(program)
    assert "Duplicate variable declaration 'gene'" in str(exc_info.value)


def test_assignment_type_mismatch():
    code = """
    DNA gene = "ATGC"
    DNA wrong = transcribe(gene)
    """
    program = parse_code(code)
    with pytest.raises(BiologicalTypeError) as exc_info:
        analyze_code(program)
    assert "Cannot assign expression of biological type 'RNA' to variable 'wrong' of type 'DNA'" in str(exc_info.value)
