"""
Tests for GenomeDSL Execution Backend.
Verifies runtime execution and Biopython integration.
"""

from genomedsl.parser import parse_code
from genomedsl.semantic_analyzer import analyze_code
from genomedsl.optimizer import ASTOptimizer
from genomedsl.backend import ExecutionBackend


def test_backend_central_dogma():
    code = """
    DNA gene = "ATGCGTACCGTA"
    RNA rna = transcribe(gene)
    Protein p = translate(rna)
    DNA rc = reverse_complement(gene)
    RESULT gc = gc_content(gene)
    RESULT sz = length(gene)
    """
    ast = parse_code(code)
    analyze_code(ast)
    backend = ExecutionBackend()
    backend.execute(ast)

    assert backend.env["gene"][0] == "ATGCGTACCGTA"
    assert backend.env["gene"][1] == "DNA"

    assert backend.env["rna"][0] == "AUGCGUACCGUA"
    assert backend.env["rna"][1] == "RNA"

    # ATGCGTACCGTA translated:
    # ATG -> M (Methionine)
    # CGT -> R (Arginine)
    # ACC -> T (Threonine)
    # GTA -> V (Valine)
    assert backend.env["p"][0] == "MRTV"
    assert backend.env["p"][1] == "Protein"

    # Reverse complement of ATGCGTACCGTA:
    # TACGCATGGCAT -> reversed -> TACGGTACGCAT
    assert backend.env["rc"][0] == "TACGGTACGCAT"
    assert backend.env["rc"][1] == "DNA"

    # GC count in ATGCGTACCGTA (12 bases): G(3), C(3) = 6/12 = 50.0%
    assert backend.env["gc"][0] == 50.0
    assert backend.env["sz"][0] == 12


def test_backend_print_capture():
    code = """
    DNA seq = "ATGC"
    PRINT "Length:", length(seq)
    """
    ast = parse_code(code)
    analyze_code(ast)
    backend = ExecutionBackend()
    backend.execute(ast)

    assert len(backend.stdout) == 1
    assert "Length: 4" in backend.stdout[0]
