"""
Symbol Table implementation for GenomeDSL.
Maintains declared variable names, biological types, and source locations.
"""

from dataclasses import dataclass
from typing import Dict, Optional, Any
from genomedsl.errors import SemanticError


# Valid primary biological and analysis types in GenomeDSL
VALID_TYPES = {"DNA", "RNA", "Protein", "RESULT"}


@dataclass
class Symbol:
    """Represents a declared symbol with its biological type and metadata."""
    name: str
    type_name: str
    line: Optional[int] = None
    column: Optional[int] = None
    value: Any = None  # Compile-time known value (if constant)

    def __repr__(self) -> str:
        loc = f" at L{self.line}:C{self.column}" if self.line else ""
        val = f" = {repr(self.value)}" if self.value is not None else ""
        return f"<Symbol {self.name}: {self.type_name}{val}{loc}>"


class SymbolTable:
    """
    Symbol Table for variable declaration and biological type tracking.
    Uses Python dictionaries to store symbols and prevent redeclarations.
    """

    def __init__(self, parent: Optional["SymbolTable"] = None):
        self._symbols: Dict[str, Symbol] = {}
        self.parent = parent

    def define(self, symbol: Symbol) -> None:
        """
        Defines a new symbol in the current scope.
        Raises SemanticError if the variable is already declared in this scope.
        """
        if symbol.name in self._symbols:
            prev = self._symbols[symbol.name]
            prev_loc = f" (previously declared at line {prev.line})" if prev.line else ""
            raise SemanticError(
                message=f"Duplicate variable declaration '{symbol.name}'{prev_loc}",
                line=symbol.line,
                column=symbol.column,
            )
        self._symbols[symbol.name] = symbol

    def lookup(self, name: str) -> Optional[Symbol]:
        """Looks up a symbol by name in current or enclosing scopes."""
        if name in self._symbols:
            return self._symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def is_defined(self, name: str) -> bool:
        """Returns True if the symbol is defined."""
        return self.lookup(name) is not None

    def all_symbols(self) -> Dict[str, Symbol]:
        """Returns a dictionary of all symbols in the current scope."""
        return dict(self._symbols)

    def __repr__(self) -> str:
        return f"SymbolTable({list(self._symbols.values())})"
