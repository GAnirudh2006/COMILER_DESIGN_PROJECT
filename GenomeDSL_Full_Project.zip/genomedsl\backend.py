"""
Execution Backend for GenomeDSL.
Interprets the validated and optimized AST using Python runtime and Biopython modules.
Delegates plotting commands to the visualizer module.
"""

from typing import Dict, Any, List, Tuple, Optional
from Bio.Seq import Seq
from Bio.SeqUtils import gc_fraction

from genomedsl.ast_nodes import (
    Program,
    Statement,
    VarDecl,
    AssignStmt,
    PrintStmt,
    PlotStmt,
    Expr,
    Literal,
    Identifier,
    FunctionCall,
)
from genomedsl.errors import GenomeDSLRuntimeError
from genomedsl.visualizer import plot_gc_content_window


class ExecutionBackend:
    """
    Executes a GenomeDSL AST.
    Maintains a runtime environment mapping variable names to their values and biological types.
    """

    def __init__(self, visual_output_dir: Optional[str] = None):
        # Maps var_name -> (value, type_name)
        self.env: Dict[str, Tuple[Any, str]] = {}
        self.stdout: List[str] = []
        self.visual_output_dir = visual_output_dir
        self.generated_plots: List[str] = []

    def execute(self, program: Program) -> Dict[str, Tuple[Any, str]]:
        """Executes all statements in the AST sequentially."""
        for stmt in program.statements:
            self.execute_statement(stmt)
        return self.env

    def execute_statement(self, stmt: Statement) -> None:
        if isinstance(stmt, VarDecl):
            val, val_type = self.eval_expr(stmt.expr)
            self.env[stmt.var_name] = (val, stmt.type_name)

        elif isinstance(stmt, AssignStmt):
            if stmt.var_name not in self.env:
                raise GenomeDSLRuntimeError(f"Cannot assign to undefined variable '{stmt.var_name}'", line=stmt.line, column=stmt.column)
            val, _ = self.eval_expr(stmt.expr)
            prev_val, prev_type = self.env[stmt.var_name]
            self.env[stmt.var_name] = (val, prev_type)

        elif isinstance(stmt, PrintStmt):
            parts = []
            for expr in stmt.expressions:
                val, _ = self.eval_expr(expr)
                parts.append(str(val))
            line_out = " ".join(parts)
            self.stdout.append(line_out)
            print(f"[GenomeDSL OUT] {line_out}")

        elif isinstance(stmt, PlotStmt):
            self.execute_plot(stmt)

        else:
            raise GenomeDSLRuntimeError(f"Unsupported statement type: {stmt.__class__.__name__}", line=stmt.line, column=stmt.column)

    def execute_plot(self, stmt: PlotStmt) -> None:
        call = stmt.call
        if call.name == "gc_content":
            if not call.args:
                raise GenomeDSLRuntimeError("PLOT gc_content requires a sequence argument", line=stmt.line, column=stmt.column)
            seq_val, seq_type = self.eval_expr(call.args[0])
            seq_name = call.args[0].name if isinstance(call.args[0], Identifier) else "sequence"
            
            # Delegate to visualizer
            plot_path = plot_gc_content_window(
                sequence=str(seq_val),
                title=f"GC-Content Profile: {seq_name} ({seq_type})",
                output_dir=self.visual_output_dir,
            )
            if plot_path:
                self.generated_plots.append(plot_path)
                msg = f"[Visualization] Generated GC plot: {plot_path}"
                self.stdout.append(msg)
                print(f"[GenomeDSL OUT] {msg}")

    def eval_expr(self, expr: Expr) -> Tuple[Any, str]:
        """Evaluates an expression node and returns (value, type_name)."""
        if isinstance(expr, Literal):
            return expr.value, expr.lit_type

        elif isinstance(expr, Identifier):
            if expr.name not in self.env:
                raise GenomeDSLRuntimeError(f"Undefined variable '{expr.name}' at runtime", line=expr.line, column=expr.column)
            return self.env[expr.name]

        elif isinstance(expr, FunctionCall):
            return self.eval_function_call(expr)

        raise GenomeDSLRuntimeError(f"Cannot evaluate expression node: {expr.__class__.__name__}", line=expr.line, column=expr.column)

    def eval_function_call(self, call: FunctionCall) -> Tuple[Any, str]:
        name = call.name
        evaluated_args = [self.eval_expr(arg) for arg in call.args]
        arg_values = [v for v, _ in evaluated_args]
        arg_types = [t for _, t in evaluated_args]

        if name == "transcribe":
            dna_seq = str(arg_values[0]).upper()
            rna_seq = str(Seq(dna_seq).transcribe())
            return rna_seq, "RNA"

        elif name == "translate":
            rna_seq = str(arg_values[0]).upper()
            protein_seq = str(Seq(rna_seq).translate(to_stop=False))
            return protein_seq, "Protein"

        elif name == "reverse_complement":
            seq_str = str(arg_values[0]).upper()
            rc_seq = str(Seq(seq_str).reverse_complement())
            return rc_seq, arg_types[0]

        elif name == "reverse":
            seq_str = str(arg_values[0])
            return seq_str[::-1], arg_types[0]

        elif name == "gc_content":
            seq_str = str(arg_values[0]).upper()
            if not seq_str:
                gc = 0.0
            else:
                gc = round(gc_fraction(seq_str) * 100.0, 2)
            return gc, "RESULT"

        elif name == "length":
            seq_str = str(arg_values[0])
            return len(seq_str), "RESULT"

        elif name == "find_motif":
            # =====================================================================
            # STUDENT ZONE - Task 3: Motif search implementation
            # Returns 1-based start indices of motif occurrences
            # =====================================================================
            seq_str = str(arg_values[0]).upper()
            motif_str = str(arg_values[1]).upper()
            matches = self._student_find_motif(seq_str, motif_str)
            return matches, "RESULT"

        elif name in ("compare", "similarity"):
            # =====================================================================
            # STUDENT ZONE - Task 2: Sequence similarity implementation
            # Returns percentage identity between two equal or aligned sequences
            # =====================================================================
            seq1 = str(arg_values[0]).upper()
            seq2 = str(arg_values[1]).upper()
            score = self._student_compare_sequences(seq1, seq2)
            return score, "RESULT"

        raise GenomeDSLRuntimeError(f"Unsupported function call '{name}'", line=call.line, column=call.column)

    def _student_find_motif(self, sequence: str, motif: str) -> List[int]:
        """
        Finds all 1-based start coordinates of 'motif' in 'sequence'.
        Supports overlapping matches (e.g. searching 'AAA' in 'AAAA').
        """
        if not motif or not sequence:
            return []
        positions = []
        pos = sequence.find(motif, 0)
        while pos != -1:
            # 1-based biological coordinate
            positions.append(pos + 1)
            pos = sequence.find(motif, pos + 1)
        return positions

    def _student_compare_sequences(self, seq1: str, seq2: str) -> float:
        """
        Calculates percentage identity between two biological sequences.
        Formula:
            matches = count of matching positions between seq1 and seq2
            identity = (matches / max(len(seq1), len(seq2))) * 100.0
        Rounded to 2 decimal places.
        """
        if not seq1 and not seq2:
            return 100.0
        max_len = max(len(seq1), len(seq2))
        if max_len == 0:
            return 0.0
        min_len = min(len(seq1), len(seq2))
        matches = sum(1 for a, b in zip(seq1[:min_len], seq2[:min_len]) if a == b)
        return round((matches / max_len) * 100.0, 2)


def execute_ast(program: Program, visual_output_dir: Optional[str] = None) -> ExecutionBackend:
    """Convenience helper to execute an AST."""
    backend = ExecutionBackend(visual_output_dir=visual_output_dir)
    backend.execute(program)
    return backend
