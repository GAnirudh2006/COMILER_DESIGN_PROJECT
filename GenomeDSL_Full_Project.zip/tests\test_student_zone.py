"""
Dedicated Test Suite for the Student Implementation Zone (25% Reserved Work).
Students should run this test suite to verify their contributions:
    pytest tests/test_student_zone.py

Tasks:
1. Task 1: Protein Alphabet Validation (semantic_analyzer.py)
2. Task 2: Sequence Comparison Semantics & Similarity Metric (semantic_analyzer.py & backend.py)
3. Task 3: Motif Search (backend.py)
4. Task 4: Reversible Operation AST Cancellation (optimizer.py)
"""

import pytest
from genomedsl.parser import parse_code
from genomedsl.semantic_analyzer import analyze_code
from genomedsl.optimizer import ASTOptimizer
from genomedsl.backend import ExecutionBackend
from genomedsl.errors import AlphabetError, BiologicalTypeError
from genomedsl.ast_nodes import Identifier


# ---------------------------------------------------------------------------
# Task 1: Protein Alphabet Validation
# ---------------------------------------------------------------------------

def test_student_task1_valid_protein():
    """Validates that standard 20 amino acid sequence is accepted."""
    code = 'Protein insulin = "GIVEQCCTSICSLYQLENYCN"'
    ast = parse_code(code)
    sym_table = analyze_code(ast)
    assert sym_table.lookup("insulin").type_name == "Protein"


def test_student_task1_invalid_protein_alphabet():
    """Validates that non-amino acid letters (e.g. 'J', 'Z') are rejected."""
    # 'J' is not a standard amino acid
    code = 'Protein bad_protein = "MVLSTAZJB"'
    ast = parse_code(code)
    with pytest.raises(AlphabetError) as exc_info:
        analyze_code(ast)
    assert "Invalid amino acid" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Task 2: Sequence Comparison Semantics & Similarity Metric
# ---------------------------------------------------------------------------

def test_student_task2_compare_same_type_dna():
    """Compares two DNA sequences of equal length with known mismatch."""
    code = """
    DNA s1 = "ATGCGTAC"
    DNA s2 = "ATGGGTAC"
    RESULT score = compare(s1, s2)
    """
    # 7 out of 8 match -> 7/8 = 87.5%
    ast = parse_code(code)
    analyze_code(ast)
    backend = ExecutionBackend()
    backend.execute(ast)
    assert backend.env["score"][0] == 87.5


def test_student_task2_compare_type_mismatch_rejected():
    """Validates that comparing DNA with RNA raises a BiologicalTypeError."""
    code = """
    DNA s1 = "ATGC"
    RNA s2 = "AUGC"
    RESULT score = compare(s1, s2)
    """
    ast = parse_code(code)
    with pytest.raises(BiologicalTypeError) as exc_info:
        analyze_code(ast)
    assert "Cannot compare sequences of differing biological types" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Task 3: Motif Search
# ---------------------------------------------------------------------------

def test_student_task3_motif_search():
    """Finds all 1-based start coordinates of a motif in a DNA sequence."""
    code = """
    DNA seq = "ATGCATGCAT"
    RESULT matches = find_motif(seq, "ATG")
    """
    # "ATG" appears at index 1 and index 5 (1-based)
    ast = parse_code(code)
    analyze_code(ast)
    backend = ExecutionBackend()
    backend.execute(ast)
    assert backend.env["matches"][0] == [1, 5]


def test_student_task3_motif_not_found():
    """Returns empty list when motif is not found."""
    code = """
    DNA seq = "ATGCATGC"
    RESULT matches = find_motif(seq, "ZZZ")
    """
    ast = parse_code(code)
    analyze_code(ast)
    backend = ExecutionBackend()
    backend.execute(ast)
    assert backend.env["matches"][0] == []


# ---------------------------------------------------------------------------
# Task 4: Reversible Operation AST Cancellation
# ---------------------------------------------------------------------------

def test_student_task4_reversible_cancellation():
    """Simplifies reverse(reverse(x)) and reverse_complement(reverse_complement(x)) to x."""
    code = """
    DNA gene = "ATGCGTAC"
    DNA rev_cancel = reverse(reverse(gene))
    DNA rc_cancel = reverse_complement(reverse_complement(gene))
    """
    ast = parse_code(code)
    opt = ASTOptimizer(enable_constant_folding=False, enable_reversible_reduction=True)
    opt_ast = opt.optimize(ast)

    # Both assignments should have had their RHS simplified directly to Identifier("gene")
    assert isinstance(opt_ast.statements[1].expr, Identifier)
    assert opt_ast.statements[1].expr.name == "gene"

    assert isinstance(opt_ast.statements[2].expr, Identifier)
    assert opt_ast.statements[2].expr.name == "gene"

    assert opt.stats["reversible_reductions"] == 2
