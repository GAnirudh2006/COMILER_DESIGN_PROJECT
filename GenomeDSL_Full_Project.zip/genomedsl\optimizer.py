"""
AST Optimizer for GenomeDSL.
Performs domain-specific compiler optimizations:
1. Constant Folding: Evaluates biological functions with constant sequence literals at compile time.
2. Reversible Operation Cancellation: Simplifies patterns like reverse(reverse(x)) and reverse_complement(reverse_complement(x)).
"""

from typing import Dict, Any, Optional
from genomedsl.ast_nodes import (
    Program,
    Statement,
    VarDecl,
    AssignStmt,
    PrintStmt,
    PlotStmt,
    Expr,
    Literal,
    Identifier,
    FunctionCall,
)


class ASTOptimizer:
    """
    Transforms the AST by applying compile-time constant folding and
    algebraic reductions on biological sequence operations.
    """

    def __init__(self, enable_constant_folding: bool = True, enable_reversible_reduction: bool = True):
        self.enable_constant_folding = enable_constant_folding
        self.enable_reversible_reduction = enable_reversible_reduction
        self.constant_env: Dict[str, Literal] = {}
        self.stats = {
            "constant_folds": 0,
            "reversible_reductions": 0,
        }

    def optimize(self, program: Program) -> Program:
        """Optimizes a full program and returns the transformed AST."""
        optimized_stmts = []
        for stmt in program.statements:
            opt_stmt = self.visit_statement(stmt)
            if opt_stmt:
                optimized_stmts.append(opt_stmt)
        return Program(line=program.line, column=program.column, statements=optimized_stmts)

    def visit_statement(self, stmt: Statement) -> Statement:
        if isinstance(stmt, VarDecl):
            stmt.expr = self.visit_expr(stmt.expr)
            if isinstance(stmt.expr, Literal):
                # Track constant in environment for propagation
                self.constant_env[stmt.var_name] = stmt.expr
            return stmt

        elif isinstance(stmt, AssignStmt):
            stmt.expr = self.visit_expr(stmt.expr)
            if isinstance(stmt.expr, Literal):
                self.constant_env[stmt.var_name] = stmt.expr
            elif stmt.var_name in self.constant_env:
                del self.constant_env[stmt.var_name]
            return stmt

        elif isinstance(stmt, PrintStmt):
            stmt.expressions = [self.visit_expr(e) for e in stmt.expressions]
            return stmt

        elif isinstance(stmt, PlotStmt):
            opt_call = self.visit_expr(stmt.call)
            if isinstance(opt_call, FunctionCall):
                stmt.call = opt_call
            return stmt

        return stmt

    def visit_expr(self, expr: Expr) -> Expr:
        """Recursively optimizes expressions."""
        if isinstance(expr, FunctionCall):
            # First optimize all arguments
            expr.args = [self.visit_expr(arg) for arg in expr.args]

            # Pass 1: Reversible operation reduction
            if self.enable_reversible_reduction:
                reduced = self._simplify_reversible_calls(expr)
                if reduced is not expr:
                    return reduced

            # Pass 2: Constant folding
            if self.enable_constant_folding:
                folded = self._fold_constant_call(expr)
                if folded is not None:
                    return folded

            return expr

        return expr

    def _fold_constant_call(self, call: FunctionCall) -> Optional[Literal]:
        """
        AI CORE IMPLEMENTATION:
        Evaluates functions with known constant literal arguments at compile-time.
        """
        # Resolve argument literals (either direct literals or known constants from env)
        arg_lits = []
        for arg in call.args:
            if isinstance(arg, Literal):
                arg_lits.append(arg)
            elif isinstance(arg, Identifier) and arg.name in self.constant_env:
                arg_lits.append(self.constant_env[arg.name])
            else:
                return None  # Non-constant argument, cannot fold

        func_name = call.name
        if func_name == "gc_content" and len(arg_lits) == 1:
            seq = str(arg_lits[0].value).upper()
            if not seq:
                gc = 0.0
            else:
                gc = round(((seq.count("G") + seq.count("C")) / len(seq)) * 100.0, 2)
            self.stats["constant_folds"] += 1
            return Literal(line=call.line, column=call.column, value=gc, lit_type="FLOAT")

        elif func_name == "transcribe" and len(arg_lits) == 1:
            seq = str(arg_lits[0].value).upper()
            rna = seq.replace("T", "U")
            self.stats["constant_folds"] += 1
            return Literal(line=call.line, column=call.column, value=rna, lit_type="STRING")

        elif func_name == "reverse" and len(arg_lits) == 1:
            seq = str(arg_lits[0].value)
            rev = seq[::-1]
            self.stats["constant_folds"] += 1
            return Literal(line=call.line, column=call.column, value=rev, lit_type="STRING")

        elif func_name == "reverse_complement" and len(arg_lits) == 1:
            seq = str(arg_lits[0].value).upper()
            complement_map = str.maketrans("ATGCU", "TACGA")
            rc = seq.translate(complement_map)[::-1]
            self.stats["constant_folds"] += 1
            return Literal(line=call.line, column=call.column, value=rc, lit_type="STRING")

        elif func_name == "length" and len(arg_lits) == 1:
            seq = str(arg_lits[0].value)
            self.stats["constant_folds"] += 1
            return Literal(line=call.line, column=call.column, value=len(seq), lit_type="INT")

        return None

    def _simplify_reversible_calls(self, call: FunctionCall) -> Expr:
        """
        Detects nested reversible operations:
        - reverse(reverse(x)) -> x
        - reverse_complement(reverse_complement(x)) -> x
        When detected, increments self.stats['reversible_reductions'] and returns inner argument x.
        Otherwise, returns call unchanged.
        """
        if call.name in ("reverse", "reverse_complement") and len(call.args) == 1:
            inner = call.args[0]
            if isinstance(inner, FunctionCall) and inner.name == call.name and len(inner.args) == 1:
                self.stats["reversible_reductions"] += 1
                return inner.args[0]
        return call


def optimize_ast(program: Program) -> Program:
    """Convenience helper to optimize an AST."""
    optimizer = ASTOptimizer()
    return optimizer.optimize(program)
